// ============================================================
// TAB0 - Dashboard Script (Restructured)
// Home, Bookmarks+Shortcuts, Statistics, Settings
// ============================================================

const INTERNAL_KEYS = ['__ssg_folders', '__ssg_settings'];
function isShortcutKey(key) { return !INTERNAL_KEYS.includes(key); }

// --- First-letter avatar fallback for missing favicons ---
var AVATAR_COLORS = [
  '#4A90D9', '#E06C75', '#98C379', '#D19A66', '#C678DD',
  '#56B6C2', '#E5C07B', '#BE5046', '#61AFEF', '#EF596F',
  '#89CA78', '#D4BC7D', '#2BBAC5', '#D55FDE', '#E8696A', '#7BC276'
];

function createLetterAvatar(name, size) {
  size = size || 18;
  let letter = (name || '?').charAt(0).toUpperCase();
  let colorIndex = letter.charCodeAt(0) % AVATAR_COLORS.length;
  let el = document.createElement('span');
  el.textContent = letter;
  el.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;width:' + size + 'px;height:' + size + 'px;border-radius:50%;background:' + AVATAR_COLORS[colorIndex] + ';color:#fff;font-size:' + Math.round(size * 0.55) + 'px;font-weight:600;flex-shrink:0;line-height:1;';
  return el;
}

function applyFaviconFallback(img, name, size) {
  img.onerror = function () {
    let avatar = createLetterAvatar(name, size || img.width || 18);
    avatar.className = img.className;
    if (img.parentNode) img.parentNode.replaceChild(avatar, img);
  };
}

// Get Chrome's internal favicon URL (same-origin, cached, no network needed)
function getChromeFaviconUrl(pageUrl, size) {
  size = size || 32;
  try {
    return chrome.runtime.getURL('_favicon/?pageUrl=' + encodeURIComponent(pageUrl) + '&size=' + size);
  } catch (e) {
    return '';
  }
}

// Check if an image is a real favicon vs Chrome's default placeholder.
// Works because _favicon URLs are same-origin so canvas is not tainted.
// Detects both colorful AND monochrome (black/white/gray) real favicons.
function isRealFavicon(img) {
  try {
    let c = document.createElement('canvas');
    let s = img.naturalWidth || 16;
    c.width = s;
    c.height = s;
    let ctx = c.getContext('2d');
    ctx.drawImage(img, 0, 0, s, s);
    let data = ctx.getImageData(0, 0, s, s).data;
    let opaquePixels = 0;
    let hasColor = false;
    let brightnessSet = new Set();
    for (let i = 0; i < data.length; i += 4) {
      let r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
      if (a > 128) {
        opaquePixels++;
        // Check for chromatic color (not gray)
        if (!hasColor && (Math.abs(r - g) > 15 || Math.abs(g - b) > 15 || Math.abs(r - b) > 15)) {
          hasColor = true;
        }
        // Track quantized brightness for monochrome diversity check
        brightnessSet.add(Math.floor((r * 0.299 + g * 0.587 + b * 0.114) / 16));
      }
    }
    let totalPixels = (s * s);
    // Mostly transparent → not a real favicon
    if (opaquePixels < totalPixels * 0.05) return false;
    // Has chromatic color → real favicon
    if (hasColor) return true;
    // Monochrome but with many distinct shades → real favicon (logos, text, etc)
    // Chrome's default placeholder has very few shade levels (< 4)
    return brightnessSet.size > 4;
  } catch (e) {
    return true;
  }
}

// Creates a favicon element with smart fallback:
// 1. Shows Google favicon immediately (fast, works for most sites)
// 2. Chrome's _favicon API checks in background:
//    - If Chrome has a REAL favicon → swap to Chrome's (proves it's real, better quality)
//    - If Chrome has NO real favicon → replace with letter avatar
//    - If _favicon fails → keep Google image as safe fallback
function createFaviconEl(url, name, cssClass, size) {
  size = size || 18;
  let wrapper = document.createElement('span');
  wrapper.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;width:' + size + 'px;height:' + size + 'px;flex-shrink:0;';
  if (cssClass) wrapper.className = cssClass;

  if (!url) {
    wrapper.appendChild(createLetterAvatar(name, size));
    return wrapper;
  }

  // Step 1: Show Google favicon immediately as placeholder
  let googleUrl;
  try { googleUrl = 'https://www.google.com/s2/favicons?domain=' + new URL(url).hostname + '&sz=' + (size > 16 ? 32 : 16); }
  catch (e) { wrapper.appendChild(createLetterAvatar(name, size)); return wrapper; }

  let img = document.createElement('img');
  img.src = googleUrl;
  img.width = size;
  img.height = size;
  img.alt = '';
  img.style.cssText = 'border-radius:4px;display:block;';
  img.onerror = function () {
    wrapper.innerHTML = '';
    wrapper.appendChild(createLetterAvatar(name, size));
  };
  wrapper.appendChild(img);

  // Step 2: Chrome's _favicon API as the authority (same-origin → canvas-readable)
  let chromeFavUrl = getChromeFaviconUrl(url, size > 16 ? 32 : 16);
  if (chromeFavUrl) {
    let checkImg = new Image();
    checkImg.onload = function () {
      if (isRealFavicon(checkImg)) {
        // Chrome has a REAL favicon → use it directly (replaces Google globe/default)
        checkImg.width = size;
        checkImg.height = size;
        checkImg.style.cssText = 'border-radius:4px;display:block;';
        wrapper.innerHTML = '';
        wrapper.appendChild(checkImg);
      } else {
        // Chrome confirms no real favicon → show letter avatar
        wrapper.innerHTML = '';
        wrapper.appendChild(createLetterAvatar(name, size));
      }
    };
    checkImg.onerror = function () {
      // _favicon failed → keep Google image as fallback
    };
    checkImg.src = chromeFavUrl;
  }
  return wrapper;
}

// --- Storage helpers ---
function storageGet(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.get(keys, (result) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(result);
    });
  });
}

function storageSet(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.set(data, () => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

function storageRemove(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.remove(keys, () => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

function isValidUrl(str) {
  try {
    let url = new URL(str);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (e) {
    return false;
  }
}

// Broader check: anything that can be bookmarked (http, https, chrome-extension, file, ftp, etc.)
function isSaveableUrl(str) {
  if (!str) return false;
  let blocked = ['about:blank', 'about:newtab', 'chrome://newtab/', 'chrome://new-tab-page/'];
  if (blocked.includes(str)) return false;
  try { new URL(str); return true; } catch (e) { return false; }
}

function debounce(fn, delay) {
  let timer;
  return function () {
    clearTimeout(timer);
    timer = setTimeout(fn, delay);
  };
}

function escapeHtml(text) {
  let div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ============================================================
// TAG GENERATION
// ============================================================
function generateTagsFromBookmark(title, url) {
  let tags = [];
  // 1. Extract domain-based tag
  try {
    let hostname = new URL(url).hostname.replace('www.', '');
    let domainTag = hostname.split('.')[0]; // e.g. "google" from "google.com"
    if (domainTag && domainTag.length > 1) tags.push(domainTag);
  } catch (e) {}
  // 2. Extract meaningful words from the title
  let titleWords = (title || '').toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2 && !['the', 'and', 'for', 'com', 'www', 'http', 'https', 'org', 'net'].includes(w));
  titleWords.forEach(function (w) {
    if (tags.length < 3 && !tags.includes(w)) tags.push(w);
  });
  // 3. Add a category tag based on URL pattern
  let urlStr = (url || '').toLowerCase();
  if (tags.length < 3) {
    if (urlStr.includes('github') || urlStr.includes('gitlab')) { if (!tags.includes('dev')) tags.push('dev'); }
    else if (urlStr.includes('docs.') || urlStr.includes('/docs') || urlStr.includes('wiki')) { if (!tags.includes('docs')) tags.push('docs'); }
    else if (urlStr.includes('mail.') || urlStr.includes('gmail') || urlStr.includes('outlook')) { if (!tags.includes('email')) tags.push('email'); }
    else if (urlStr.includes('drive.') || urlStr.includes('dropbox') || urlStr.includes('cloud')) { if (!tags.includes('cloud')) tags.push('cloud'); }
    else if (urlStr.includes('youtube') || urlStr.includes('vimeo') || urlStr.includes('video')) { if (!tags.includes('video')) tags.push('video'); }
    else if (urlStr.includes('chat') || urlStr.includes('slack') || urlStr.includes('discord') || urlStr.includes('teams')) { if (!tags.includes('chat')) tags.push('chat'); }
    else if (urlStr.includes('figma') || urlStr.includes('canva') || urlStr.includes('design')) { if (!tags.includes('design')) tags.push('design'); }
    else if (urlStr.includes('support') || urlStr.includes('desk') || urlStr.includes('helpdesk') || urlStr.includes('ticket')) { if (!tags.includes('support')) tags.push('support'); }
  }
  return tags.slice(0, 3);
}

// Build a tags input widget inside the modal
function createTagsInput(containerId, existingTags) {
  let wrapper = document.getElementById(containerId);
  if (!wrapper) return;
  existingTags = existingTags || [];

  function render() {
    wrapper.innerHTML = '';
    wrapper.className = 'tags-input-wrapper';

    let tagsRow = document.createElement('div');
    tagsRow.className = 'tags-input-tags';

    existingTags.forEach(function (tag, idx) {
      let pill = document.createElement('span');
      pill.className = 'tag-pill tag-pill-editable';
      pill.textContent = tag;

      let removeBtn = document.createElement('button');
      removeBtn.className = 'tag-pill-remove';
      removeBtn.innerHTML = '&times;';
      removeBtn.title = 'Remove tag';
      removeBtn.addEventListener('click', function (e) {
        e.preventDefault();
        existingTags.splice(idx, 1);
        render();
      });
      pill.appendChild(removeBtn);
      tagsRow.appendChild(pill);
    });

    wrapper.appendChild(tagsRow);

    if (existingTags.length < 5) {
      let addInput = document.createElement('input');
      addInput.type = 'text';
      addInput.className = 'tags-input-field';
      addInput.placeholder = existingTags.length === 0 ? 'Add a tag...' : 'Add another...';
      addInput.maxLength = 20;
      addInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ',') {
          e.preventDefault();
          let val = this.value.trim().toLowerCase().replace(/[^a-z0-9-]/g, '');
          if (val && !existingTags.includes(val) && existingTags.length < 5) {
            existingTags.push(val);
            render();
          } else {
            this.value = '';
          }
        }
      });
      wrapper.appendChild(addInput);
    }
  }

  render();
  return {
    getTags: function () { return existingTags.slice(); },
    addTag: function (tag) {
      tag = String(tag).trim().toLowerCase().replace(/[^a-z0-9-]/g, '');
      if (tag && !existingTags.includes(tag) && existingTags.length < 5) {
        existingTags.push(tag);
        render();
        return true;
      }
      return false;
    }
  };
}

// ============================================================
// TOAST
// ============================================================
function showToast(message, type) {
  type = type || 'info';
  let toast = document.getElementById('dashToast');
  toast.textContent = message;
  toast.className = 'toast toast-' + type;
  setTimeout(() => toast.classList.add('toast-visible'), 10);
  setTimeout(() => {
    toast.classList.remove('toast-visible');
    setTimeout(() => toast.className = 'toast hidden', 300);
  }, 3000);
}

// ============================================================
// MODAL
// ============================================================
function showModal(options) {
  let overlay = document.getElementById('dashModalOverlay');
  document.getElementById('dashModalTitle').textContent = options.title || '';
  document.getElementById('dashModalBody').textContent = options.body || '';

  let inputsEl = document.getElementById('dashModalInputs');
  let actionsEl = document.getElementById('dashModalActions');
  inputsEl.innerHTML = '';
  actionsEl.innerHTML = '';

  if (options.inputs) {
    options.inputs.forEach(function (inp) {
      let label = document.createElement('label');
      label.textContent = inp.label;
      label.setAttribute('for', 'dm-input-' + inp.id);

      let input;
      if (inp.type === 'select') {
        input = document.createElement('select');
        input.id = 'dm-input-' + inp.id;
        input.className = 'dm-input';
        let opts = inp.selectOptions || (inp.options || []).map(o => ({ value: o, label: o || '(None)' }));
        opts.forEach(function (opt) {
          let o = document.createElement('option');
          o.value = opt.value;
          o.textContent = opt.label;
          if (String(opt.value) === String(inp.value)) o.selected = true;
          input.appendChild(o);
        });
      } else if (inp.type === 'checkbox') {
        // Checkbox input: rendered inline with label
        let wrapper = document.createElement('div');
        wrapper.style.cssText = 'display:flex;align-items:center;gap:8px;margin:4px 0 8px;';
        input = document.createElement('input');
        input.type = 'checkbox';
        input.id = 'dm-input-' + inp.id;
        input.checked = !!inp.checked;
        input.style.cssText = 'width:16px;height:16px;accent-color:var(--accent);cursor:pointer;';
        let cbLabel = document.createElement('label');
        cbLabel.setAttribute('for', 'dm-input-' + inp.id);
        cbLabel.textContent = inp.checkboxLabel || inp.label;
        cbLabel.style.cssText = 'cursor:pointer;font-size:13px;color:var(--text-secondary);user-select:none;';
        wrapper.appendChild(input);
        wrapper.appendChild(cbLabel);
        // Skip normal label/input append — use wrapper instead
        inputsEl.appendChild(wrapper);
        return;
      } else if (inp.type === 'tags') {
        // Tags input: renders as a container, filled after DOM insertion
        input = document.createElement('div');
        input.id = 'dm-input-' + inp.id;
        input.className = 'tags-input-container';
      } else {
        input = document.createElement('input');
        input.type = inp.type || 'text';
        input.id = 'dm-input-' + inp.id;
        input.value = inp.value || '';
        input.placeholder = inp.placeholder || '';
        input.className = 'dm-input';
      }

      inputsEl.appendChild(label);
      inputsEl.appendChild(input);
    });
  }

  // Render tags inputs after DOM is ready
  if (options._tagsInputs) {
    options._tagsInputs.forEach(function (tagConf) {
      tagConf.instance = createTagsInput('dm-input-' + tagConf.id, tagConf.tags.slice());
    });
  }

  if (options.buttons) {
    options.buttons.forEach(function (btn) {
      let button = document.createElement('button');
      button.textContent = btn.text;
      button.className = 'dm-btn ' + (btn.className || '');
      button.addEventListener('click', function () {
        hideModal();
        if (btn.onClick) btn.onClick();
      });
      actionsEl.appendChild(button);
    });
  }

  overlay.classList.remove('hidden');
  let firstInput = inputsEl.querySelector('input, select');
  if (firstInput) setTimeout(() => firstInput.focus(), 50);
  if (options.afterRender) setTimeout(() => options.afterRender(), 60);
}

function hideModal() {
  document.getElementById('dashModalOverlay').classList.add('hidden');
}

document.getElementById('dashModalOverlay').addEventListener('click', function (e) {
  if (e.target === this) hideModal();
});

// ============================================================
// THEME
// ============================================================
function applyTheme(theme) {
  document.body.className = theme === 'light' ? 'theme-light' : 'theme-dark';
  localStorage.setItem('tab0_theme', theme);
  // Update theme toggle buttons
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-theme') === theme);
  });
}

// Init theme
(function () {
  let saved = localStorage.getItem('tab0_theme') || 'dark';
  applyTheme(saved);
})();

document.querySelectorAll('.theme-btn').forEach(btn => {
  btn.addEventListener('click', function () {
    applyTheme(this.getAttribute('data-theme'));
  });
});

// ============================================================
// SIDEBAR TOGGLE
// ============================================================
document.getElementById('sidebarToggle').addEventListener('click', function () {
  let sidebar = document.getElementById('sidebar');
  let main = document.querySelector('.main');
  sidebar.classList.toggle('collapsed');
  main.classList.toggle('sidebar-collapsed');
  localStorage.setItem('tab0_sidebar_collapsed', sidebar.classList.contains('collapsed'));
});

document.querySelector('.sidebar-logo-wrapper').addEventListener('click', function () {
  let sidebar = document.getElementById('sidebar');
  if (sidebar.classList.contains('collapsed')) {
    sidebar.classList.remove('collapsed');
    document.querySelector('.main').classList.remove('sidebar-collapsed');
    localStorage.setItem('tab0_sidebar_collapsed', 'false');
  }
});

if (localStorage.getItem('tab0_sidebar_collapsed') === 'true') {
  document.getElementById('sidebar').classList.add('collapsed');
  document.querySelector('.main').classList.add('sidebar-collapsed');
}

// ============================================================
// NAVIGATION
// ============================================================
document.querySelectorAll('.nav-item').forEach(function (btn) {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    let viewId = btn.getAttribute('data-view');
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.getElementById('view-' + viewId).classList.add('active');

    if (viewId === 'bookmarks') { loadBookmarksView(); loadShortcutsTable(); }
    if (viewId === 'stats') loadStatsView();
    if (viewId === 'settings') loadSettingsState();
  });
});

// Bookmark subtab switching
document.querySelectorAll('.tab-btn').forEach(function (btn) {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    let subtabId = btn.getAttribute('data-subtab');
    document.querySelectorAll('.subtab').forEach(s => s.classList.remove('active'));
    document.getElementById('subtab-' + subtabId).classList.add('active');
  });
});

// ============================================================
// (Home view removed — Bookmarks is now the main section)
// ============================================================


// ============================================================
// SHORTCUTS TABLE (now under Bookmarks tab)
// ============================================================
let activeTagFilters = [];

// Search scoring for dashboard: Shortcut Name > Bookmark Name > Tags > URL
function getDashSearchScore(key, data, searchVal) {
  if (!searchVal) return 100;
  let url = typeof data === 'object' ? (data.url || '') : (data || '');
  let bookmarkTitle = typeof data === 'object' ? (data.bookmarkTitle || '') : '';
  let tags = typeof data === 'object' && Array.isArray(data.tags) ? data.tags : [];
  let score = 0;

  let lk = key.toLowerCase();
  let lt = bookmarkTitle.toLowerCase();
  let lu = url.toLowerCase();

  if (lk === searchVal) score += 400;
  else if (lk.startsWith(searchVal)) score += 300;
  else if (lk.includes(searchVal)) score += 200;

  if (lt === searchVal) score += 150;
  else if (lt.startsWith(searchVal)) score += 120;
  else if (lt.includes(searchVal)) score += 100;
  else { let words = lt.split(/\s+/); if (words.some(w => w.startsWith(searchVal))) score += 90; }

  for (let t of tags) {
    if (t === searchVal) { score += 80; break; }
    if (t.startsWith(searchVal)) { score += 60; break; }
    if (t.includes(searchVal)) { score += 40; break; }
  }

  if (lu.includes(searchVal)) score += 20;
  return score;
}

async function loadShortcutsTable() {
  let searchVal = (document.getElementById('bookmarkSearchInput').value || '').toLowerCase().trim();
  let filterVal = document.getElementById('shortcutFilter') ? document.getElementById('shortcutFilter').value : 'most-used';

  try {
    let items = await storageGet(null);
    let tbody = document.getElementById('shortcutsTableBody');
    tbody.innerHTML = '';

    // Collect all unique tags for the filter bar
    let allTags = {};
    Object.keys(items).filter(isShortcutKey).forEach(function (k) {
      let d = items[k];
      if (typeof d === 'object' && Array.isArray(d.tags)) {
        d.tags.forEach(function (t) { allTags[t] = (allTags[t] || 0) + 1; });
      }
    });

    // Render tag filter bar
    let existingBar = document.getElementById('tagFilterBar');
    if (existingBar) existingBar.remove();
    let sortedTags = Object.keys(allTags).sort((a, b) => allTags[b] - allTags[a]).slice(0, 20);
    if (sortedTags.length > 0) {
      let bar = document.createElement('div');
      bar.id = 'tagFilterBar';
      bar.className = 'tag-filter-bar';
      sortedTags.forEach(function (tag) {
        let pill = document.createElement('button');
        pill.className = 'tag-filter-pill' + (activeTagFilters.includes(tag) ? ' active' : '');
        pill.textContent = tag;
        pill.addEventListener('click', function () {
          let idx = activeTagFilters.indexOf(tag);
          if (idx > -1) activeTagFilters.splice(idx, 1);
          else activeTagFilters.push(tag);
          loadShortcutsTable();
        });
        bar.appendChild(pill);
      });
      // Insert before the card table
      let shortcutsSubtab = document.getElementById('subtab-bm-shortcuts');
      let card = shortcutsSubtab.querySelector('.card');
      if (card) shortcutsSubtab.insertBefore(bar, card);
    }

    let keys = Object.keys(items).filter(isShortcutKey);

    // Sort: if searching, prioritize by search score; otherwise use filter
    if (searchVal) {
      keys.sort((a, b) => {
        let scoreA = getDashSearchScore(a, items[a], searchVal);
        let scoreB = getDashSearchScore(b, items[b], searchVal);
        if (scoreB !== scoreA) return scoreB - scoreA;
        return ((typeof items[b] === 'object' ? items[b].count : 0) || 0) - ((typeof items[a] === 'object' ? items[a].count : 0) || 0);
      });
    } else if (filterVal === 'most-used') {
      keys.sort((a, b) => ((typeof items[b] === 'object' ? items[b].count : 0) || 0) - ((typeof items[a] === 'object' ? items[a].count : 0) || 0));
    } else if (filterVal === 'recently-accessed') {
      keys.sort((a, b) => {
        let aTime = typeof items[a] === 'object' ? (items[a].lastAccessed || 0) : 0;
        let bTime = typeof items[b] === 'object' ? (items[b].lastAccessed || 0) : 0;
        return bTime - aTime;
      });
    } else if (filterVal === 'time-created') {
      keys.sort((a, b) => {
        let aTime = typeof items[a] === 'object' ? (items[a].createdAt || 0) : 0;
        let bTime = typeof items[b] === 'object' ? (items[b].createdAt || 0) : 0;
        return bTime - aTime;
      });
    } else if (filterVal === 'alphabetical') {
      keys.sort((a, b) => a.localeCompare(b));
    }

    let visibleCount = 0;

    keys.forEach(function (key) {
      let data = items[key];
      let isFolder = typeof data === 'object' && data.type === 'folder';
      let url = typeof data === 'object' ? (data.url || '') : (data || '');
      let count = typeof data === 'object' ? (data.count || 0) : 0;
      let tags = typeof data === 'object' && Array.isArray(data.tags) ? data.tags : [];

      // Search scoring
      if (searchVal && getDashSearchScore(key, data, searchVal) === 0) return;
      // Tag filter: must have ALL active filter tags
      if (activeTagFilters.length > 0 && !activeTagFilters.every(ft => tags.includes(ft))) return;
      visibleCount++;

      let tr = document.createElement('tr');

      let tdFav = document.createElement('td');
      tdFav.className = 'favicon-cell';
      if (isFolder) {
        tdFav.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';
      } else {
        tdFav.appendChild(createFaviconEl(url, key, '', 16));
      }
      tr.appendChild(tdFav);

      let tdName = document.createElement('td');
      let nameStrong = document.createElement('strong');
      nameStrong.textContent = key;
      tdName.appendChild(nameStrong);
      // Show tags inline next to the name
      if (tags.length > 0) {
        let tagsSpan = document.createElement('span');
        tagsSpan.className = 'shortcut-tags-inline';
        tags.forEach(function (tag) {
          let pill = document.createElement('span');
          pill.className = 'tag-pill tag-pill-sm';
          pill.textContent = tag;
          pill.setAttribute('data-tooltip', tag);
          tagsSpan.appendChild(pill);
        });
        tdName.appendChild(tagsSpan);
      }
      tr.appendChild(tdName);

      let tdUrl = document.createElement('td');
      tdUrl.className = 'url-cell';
      if (isFolder) {
        let folderLabel = document.createElement('span');
        folderLabel.className = 'folder-url-label';
        let urlCount = Array.isArray(data.urls) ? data.urls.length : 0;
        folderLabel.textContent = (data.folderTitle || key) + ' (' + urlCount + ' tab' + (urlCount !== 1 ? 's' : '') + ')';
        tdUrl.appendChild(folderLabel);
      } else {
        let urlLink = document.createElement('a');
        urlLink.href = url;
        urlLink.target = '_blank';
        urlLink.textContent = url.length > 50 ? url.substring(0, 50) + '...' : url;
        urlLink.title = url;
        tdUrl.appendChild(urlLink);
      }
      tr.appendChild(tdUrl);

      let tdCount = document.createElement('td');
      let countBadge = document.createElement('span');
      countBadge.className = 'count-badge';
      countBadge.textContent = count;
      tdCount.appendChild(countBadge);
      tr.appendChild(tdCount);

      let tdActions = document.createElement('td');
      tdActions.className = 'actions-cell';

      let editBtn = document.createElement('button');
      editBtn.className = 'btn btn-sm btn-edit';
      editBtn.textContent = 'Edit';
      editBtn.addEventListener('click', () => editShortcutDash(key, url, count));
      tdActions.appendChild(editBtn);

      let deleteBtn = document.createElement('button');
      deleteBtn.className = 'btn btn-sm btn-delete';
      deleteBtn.textContent = 'Delete';
      deleteBtn.addEventListener('click', () => deleteShortcutDash(key, url));
      tdActions.appendChild(deleteBtn);

      tr.appendChild(tdActions);
      tbody.appendChild(tr);
    });

    let emptyState = document.getElementById('emptyState');
    emptyState.classList.toggle('hidden', visibleCount > 0);
  } catch (err) {
    showToast('Error loading shortcuts: ' + err.message, 'error');
  }
}

document.getElementById('addShortcutBtn').addEventListener('click', async function () {
  let params = new URLSearchParams(window.location.search);
  let prefillUrl = params.get('newurl') || '';
  let prefillTitle = params.get('newtitle') || '';
  let suggestedName = prefillTitle ? prefillTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').substring(0, 15).replace(/-$/, '') : '';
  let autoTags = (prefillUrl && prefillTitle) ? generateTagsFromBookmark(prefillTitle, prefillUrl) : [];

  // Try AI-powered tag & shortcut name generation (non-blocking, fills in after modal opens)
  let aiTagsPromise = null;
  let aiNamePromise = null;
  if (prefillUrl && prefillTitle) {
    aiTagsPromise = new Promise(function (resolve) {
      let timeout = setTimeout(function () { resolve(null); }, 6000);
      chrome.runtime.sendMessage({ action: 'ai:generateTags', title: prefillTitle, url: prefillUrl }, function (r) {
        clearTimeout(timeout);
        if (chrome.runtime.lastError) { resolve(null); return; }
        resolve(r && r.tags ? r.tags : null);
      });
    });
    aiNamePromise = new Promise(function (resolve) {
      let timeout = setTimeout(function () { resolve(null); }, 6000);
      chrome.runtime.sendMessage({ action: 'ai:generateShortcutName', title: prefillTitle, url: prefillUrl }, function (r) {
        clearTimeout(timeout);
        if (chrome.runtime.lastError) { resolve(null); return; }
        resolve(r && r.name ? r.name : null);
      });
    });
  }

  let newShortcutTagsConf = { id: 'tags', tags: autoTags.slice() };

  // Load folders for folder dropdown
  chrome.runtime.sendMessage({ action: 'getBookmarkFolders' }, function (folders) {
    if (chrome.runtime.lastError) folders = [];
    folders = folders || [];
    let folderSelectData = [{ value: '', label: 'No folder' }].concat(
      folders.map(function (f) {
        let indent = '';
        for (let i = 0; i < f.depth; i++) indent += '\u00A0\u00A0';
        return { value: f.id, label: indent + (f.title || '(Untitled)') };
      })
    );

    showModal({
      title: 'New Shortcut',
      inputs: [
        { id: 'url', label: 'URL', value: prefillUrl, placeholder: 'https://example.com' },
        { id: 'name', label: 'Tab0 Shortcut (max 15 chars, no spaces)', value: suggestedName, placeholder: 'e.g. yt' },
        { id: 'folder', label: 'Bookmark Folder', type: 'select', selectOptions: folderSelectData, value: '' },
        { id: 'tags', label: 'Tags (optional, up to 5, press Enter to add)', type: 'tags' }
      ],
      _tagsInputs: [newShortcutTagsConf],
      buttons: [
        { text: 'Cancel', className: 'dm-btn-cancel' },
        {
          text: 'Save', className: 'dm-btn-save', onClick: async function () {
            let name = document.getElementById('dm-input-name').value.trim().toLowerCase();
            let url = document.getElementById('dm-input-url').value.trim();
            let tags = newShortcutTagsConf.instance ? newShortcutTagsConf.instance.getTags() : [];
            let folderSelect = document.getElementById('dm-input-folder');
            let folderId = folderSelect ? folderSelect.value : '';
            if (!name) { showToast('Name required.', 'error'); return; }
            if (name.length > 15) { showToast('Name too long (max 15).', 'error'); return; }
            if (/\s/.test(name)) { showToast('No spaces in name.', 'error'); return; }
            if (!url || !isSaveableUrl(url)) { showToast('Valid URL required.', 'error'); return; }
            try {
              let all = await storageGet(null);
              if (all[name] && isShortcutKey(name)) { showToast(name + ' already exists!', 'error'); return; }
              // Default to Tab0 Shortcuts folder if none selected
              if (!folderId) {
                try {
                  folderId = await new Promise(resolve => {
                    chrome.runtime.sendMessage({ action: 'getTab0FolderId' }, resolve);
                  });
                } catch (e) {}
              }
              // Create Chrome bookmark
              let bookmarkId, bookmarkTitle;
              if (folderId) {
                try {
                  let bm = await new Promise((resolve, reject) => {
                    chrome.bookmarks.create({ title: name, url: url, parentId: folderId }, (result) => {
                      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                      else resolve(result);
                    });
                  });
                  bookmarkId = bm.id;
                  bookmarkTitle = name;
                } catch (e) { /* bookmark creation failed, still save shortcut */ }
              }
              let shortcutData = { url: url, count: 0, tags: tags, createdAt: Date.now() };
              if (bookmarkId) { shortcutData.bookmarkId = bookmarkId; shortcutData.bookmarkTitle = bookmarkTitle; }
              await storageSet({ [name]: shortcutData });
              showToast('Created ' + name, 'success');
              if (prefillUrl) window.history.replaceState({}, '', 'manage.html');
              loadShortcutsTable();
            } catch (err) {
              showToast('Error: ' + err.message, 'error');
            }
          }
        }
      ],
      afterRender: function () {
        // Fill in AI-generated tags and shortcut name when they arrive
        if (aiNamePromise) {
          aiNamePromise.then(function (aiName) {
            if (!aiName) return;
            let nameInput = document.getElementById('dm-input-name');
            if (nameInput && !nameInput.value.trim()) {
              nameInput.value = aiName;
              nameInput.style.borderColor = 'var(--accent)';
              setTimeout(function () { nameInput.style.borderColor = ''; }, 2000);
            }
          });
        }
        if (aiTagsPromise) {
          aiTagsPromise.then(function (aiTags) {
            if (!aiTags || aiTags.length === 0) return;
            if (newShortcutTagsConf.instance) {
              let currentTags = newShortcutTagsConf.instance.getTags();
              if (currentTags.length === 0 || (currentTags.length <= 3 && autoTags.length > 0)) {
                // Replace basic tags with AI tags if user hasn't manually edited
                aiTags.forEach(function (t) {
                  if (currentTags.length < 5 && !currentTags.includes(t)) {
                    newShortcutTagsConf.instance.addTag(t);
                  }
                });
              }
            }
          });
        }
      }
    });
  });
});

function editShortcutDash(key, url, count) {
  // Load existing data including tags
  storageGet(key).then(function (result) {
    let data = result[key] || {};
    let isFolder = typeof data === 'object' && data.type === 'folder';
    let existingTags = (typeof data === 'object' && data.tags) ? data.tags : generateTagsFromBookmark('', url);
    let editTagsConf = { id: 'tags', tags: existingTags.slice() };

    // For folder shortcuts, show simpler edit modal
    if (isFolder) {
      showModal({
        title: 'Edit Folder Shortcut',
        inputs: [
          { id: 'name', label: 'Shortcut name', value: key, placeholder: 'e.g. work' },
          { id: 'tags', label: 'Tags (up to 5, press Enter to add)', type: 'tags' }
        ],
        _tagsInputs: [editTagsConf],
        buttons: [
          { text: 'Cancel', className: 'dm-btn-cancel' },
          {
            text: 'Save', className: 'dm-btn-save', onClick: async function () {
              let newName = document.getElementById('dm-input-name').value.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
              let tags = editTagsConf.instance ? editTagsConf.instance.getTags() : [];
              if (!newName) { showToast('Name required.', 'error'); return; }
              if (newName.length > 15) { showToast('Name too long.', 'error'); return; }
              try {
                let all = await storageGet(null);
                if (all[newName] && newName !== key) { showToast(newName + ' already exists!', 'error'); return; }
                await storageRemove(key);
                await storageSet({ [newName]: { type: 'folder', urls: data.urls || [], folderId: data.folderId, folderTitle: data.folderTitle || newName, count: data.count || 0, tags: tags, createdAt: data.createdAt || Date.now() } });
                showToast('Updated ' + newName, 'success');
                loadShortcutsTable();
              } catch (err) { showToast('Error: ' + err.message, 'error'); }
            }
          }
        ]
      });
      return;
    }

    // Load folders for folder dropdown (regular shortcuts only)
    chrome.runtime.sendMessage({ action: 'getBookmarkFolders' }, function (folders) {
      if (chrome.runtime.lastError) folders = [];
      folders = folders || [];
      let folderSelectData = [{ value: '', label: 'No folder' }].concat(
        folders.map(function (f) {
          let indent = '';
          for (let i = 0; i < f.depth; i++) indent += '\u00A0\u00A0';
          return { value: f.id, label: indent + (f.title || '(Untitled)') };
        })
      );

      showModal({
        title: 'Edit ' + key,
        inputs: [
          { id: 'name', label: 'Shortcut name', value: key, placeholder: 'e.g. yt' },
          { id: 'url', label: 'URL', value: url, placeholder: 'https://example.com' },
          { id: 'tags', label: 'Tags (up to 5, press Enter to add)', type: 'tags' },
          { id: 'folder', label: 'Folder', type: 'select', selectOptions: folderSelectData, value: '' }
        ],
        _tagsInputs: [editTagsConf],
        buttons: [
          { text: 'Cancel', className: 'dm-btn-cancel' },
          {
            text: 'Save', className: 'dm-btn-save', onClick: async function () {
              let newName = document.getElementById('dm-input-name').value.trim().toLowerCase();
              let newUrl = document.getElementById('dm-input-url').value.trim();
              let tags = editTagsConf.instance ? editTagsConf.instance.getTags() : [];
              let folderSelect = document.getElementById('dm-input-folder');
              let folderId = folderSelect ? folderSelect.value : '';
              if (!newName) { showToast('Name required.', 'error'); return; }
              if (newName.length > 15) { showToast('Name too long.', 'error'); return; }
              if (/\s/.test(newName)) { showToast('No spaces.', 'error'); return; }
              if (!newUrl || !isSaveableUrl(newUrl)) { showToast('Invalid URL.', 'error'); return; }
              try {
                let all = await storageGet(null);
                if (all[newName] && newName !== key) { showToast(newName + ' already exists!', 'error'); return; }
                let oldData = all[key] || {};
                let preservedData = typeof oldData === 'object' ? oldData : {};

                // If there's an associated bookmark, update it too
                if (preservedData.bookmarkId) {
                  chrome.runtime.sendMessage({
                    action: 'updateBookmark', id: preservedData.bookmarkId,
                    title: preservedData.bookmarkTitle || newName, url: newUrl,
                    parentId: folderId || undefined
                  });
                }

                await storageRemove(key);
                await storageSet({ [newName]: { url: newUrl, count: count, tags: tags, bookmarkId: preservedData.bookmarkId || undefined, bookmarkTitle: preservedData.bookmarkTitle || undefined, createdAt: preservedData.createdAt || Date.now() } });
                showToast('Updated ' + newName, 'success');
                loadShortcutsTable();
              } catch (err) {
                showToast('Error: ' + err.message, 'error');
              }
            }
          }
        ]
      });
    });
  });
}

function deleteShortcutDash(key) {
  showModal({
    title: 'Delete Shortcut',
    body: 'Permanently delete "' + key + '"?',
    buttons: [
      { text: 'Cancel', className: 'dm-btn-cancel' },
      {
        text: 'Delete', className: 'dm-btn-danger', onClick: async function () {
          try {
            await storageRemove(key);
            showToast(key + ' deleted.', 'success');
            loadShortcutsTable();
          } catch (err) {
            showToast('Error: ' + err.message, 'error');
          }
        }
      }
    ]
  });
}

// ============================================================
// STATS VIEW (enhanced)
// ============================================================
// Helper: format relative time
function formatTimeAgo(timestamp) {
  if (!timestamp) return 'Never';
  let diff = Date.now() - timestamp;
  let mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return mins + 'm ago';
  let hrs = Math.floor(mins / 60);
  if (hrs < 24) return hrs + 'h ago';
  let days = Math.floor(hrs / 24);
  if (days < 30) return days + 'd ago';
  let months = Math.floor(days / 30);
  if (months < 12) return months + 'mo ago';
  return Math.floor(months / 12) + 'y ago';
}

let _statsCurrentPeriod = 'daily';

async function loadStatsView() {
  try {
    let items = await storageGet(null);
    let keys = Object.keys(items).filter(isShortcutKey);

    // Count bookmarks from tree
    let bookmarkCount = 0;
    try {
      let tree = await new Promise(resolve => chrome.bookmarks.getTree(resolve));
      function countBm(node) { if (node.url) bookmarkCount++; if (node.children) node.children.forEach(countBm); }
      tree.forEach(countBm);
    } catch (e) {}

    let totalShortcuts = keys.length;
    let totalUses = 0;
    let usedCount = 0;
    let topShortcut = { name: '-', count: 0 };

    let sorted = keys.map(function (key) {
      let data = items[key];
      let count = typeof data === 'object' ? (data.count || 0) : 0;
      let lastAccessed = typeof data === 'object' ? (data.lastAccessed || 0) : 0;
      let bookmarkTitle = typeof data === 'object' ? (data.bookmarkTitle || '') : '';
      let url = typeof data === 'object' ? (data.url || '') : (data || '');
      totalUses += count;
      if (count > 0) usedCount++;
      if (count > topShortcut.count) topShortcut = { name: key, count: count };
      return { name: key, count: count, lastAccessed: lastAccessed, bookmarkTitle: bookmarkTitle, url: url };
    });

    sorted.sort((a, b) => b.count - a.count);

    // Open rate
    let openRate = totalShortcuts > 0 ? Math.round((usedCount / totalShortcuts) * 100) : 0;

    // Average revisit frequency (total uses / shortcuts that have been used)
    let avgRevisit = usedCount > 0 ? (totalUses / usedCount).toFixed(1) : '0';

    // ---- TOP STAT CARDS ----
    let cardsEl = document.getElementById('statsCards');
    cardsEl.innerHTML = '';

    let statCards = [
      { label: 'Total Bookmarks', value: bookmarkCount, icon: '📚' },
      { label: 'Total Opens', value: totalUses, icon: '🔗' },
      { label: 'Open Rate', value: openRate + '%', icon: '📊' },
      { label: 'Most Opened', value: topShortcut.name !== '-' ? topShortcut.name : '-', icon: '⭐' },
      { label: 'Dead Bookmarks', value: sorted.filter(s => s.count === 0).length, icon: '💀' },
      { label: 'Avg Revisit Freq', value: avgRevisit + 'x', icon: '🔄' }
    ];

    statCards.forEach(function (s) {
      let card = document.createElement('div');
      card.className = 'stat-card';
      card.innerHTML = '<div class="stat-card-icon">' + s.icon + '</div><div class="stat-value">' + escapeHtml(String(s.value)) + '</div><div class="stat-label">' + s.label + '</div>';
      cardsEl.appendChild(card);
    });

    // ---- TIMELINE (daily/weekly/monthly) ----
    let dailyStats = {};
    try {
      dailyStats = await new Promise(resolve => {
        chrome.runtime.sendMessage({ action: 'getDailyStats' }, resolve);
      }) || {};
    } catch (e) {}

    renderTimeline(dailyStats, _statsCurrentPeriod);

    // Period tab switching
    document.querySelectorAll('.stats-period-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        document.querySelectorAll('.stats-period-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        _statsCurrentPeriod = btn.getAttribute('data-period');
        renderTimeline(dailyStats, _statsCurrentPeriod);
      });
    });

    // ---- MOST OPENED (top 10) ----
    let top10 = sorted.filter(s => s.count > 0).slice(0, 10);
    let maxCount = top10.length > 0 ? top10[0].count : 1;
    if (maxCount === 0) maxCount = 1;

    let chartEl = document.getElementById('statsMostVisited');
    chartEl.innerHTML = '';

    top10.forEach(function (s) {
      let row = document.createElement('div');
      row.className = 'bar-row';
      let label = document.createElement('div');
      label.className = 'bar-label';
      label.textContent = s.name;
      let barWrapper = document.createElement('div');
      barWrapper.className = 'bar-wrapper';
      let bar = document.createElement('div');
      bar.className = 'bar-fill';
      bar.style.width = Math.max((s.count / maxCount) * 100, 2) + '%';
      let countLabel = document.createElement('span');
      countLabel.className = 'bar-count';
      countLabel.textContent = s.count;
      barWrapper.appendChild(bar);
      barWrapper.appendChild(countLabel);
      row.appendChild(label);
      row.appendChild(barWrapper);
      chartEl.appendChild(row);
    });

    if (top10.length === 0) {
      chartEl.innerHTML = '<p style="color:var(--text-muted);padding:20px;">No usage data yet.</p>';
    }

    // ---- DEAD BOOKMARKS (never opened) ----
    let deadEl = document.getElementById('statsDeadBookmarks');
    deadEl.innerHTML = '';
    let deadBookmarks = sorted.filter(s => s.count === 0).slice(0, 15);
    deadBookmarks.forEach(function (s) {
      let item = document.createElement('div');
      item.className = 'stats-list-item';
      let nameSpan = document.createElement('span');
      nameSpan.className = 'stats-dead-name';
      nameSpan.textContent = s.name;
      let urlSpan = document.createElement('span');
      urlSpan.className = 'stats-dead-url';
      try { urlSpan.textContent = new URL(s.url).hostname; } catch (e) { urlSpan.textContent = ''; }
      item.appendChild(nameSpan);
      item.appendChild(urlSpan);
      deadEl.appendChild(item);
    });
    if (deadBookmarks.length === 0) {
      deadEl.innerHTML = '<p style="color:var(--text-muted);padding:20px;">All bookmarks have been used!</p>';
    }

    // ---- TIME SINCE LAST OPENED ----
    let lastOpenedEl = document.getElementById('statsLastOpened');
    lastOpenedEl.innerHTML = '';
    let usedSorted = sorted.filter(s => s.lastAccessed > 0).sort((a, b) => a.lastAccessed - b.lastAccessed).slice(0, 15);
    usedSorted.forEach(function (s) {
      let item = document.createElement('div');
      item.className = 'stats-list-item';
      let nameSpan = document.createElement('span');
      nameSpan.textContent = s.name;
      let timeSpan = document.createElement('span');
      timeSpan.className = 'stats-time-ago';
      timeSpan.textContent = formatTimeAgo(s.lastAccessed);
      item.appendChild(nameSpan);
      item.appendChild(timeSpan);
      lastOpenedEl.appendChild(item);
    });
    if (usedSorted.length === 0) {
      lastOpenedEl.innerHTML = '<p style="color:var(--text-muted);padding:20px;">No usage data yet.</p>';
    }

    // ---- TAGS CLOUD ----
    let tagCloudEl = document.getElementById('statsTagCloud');
    tagCloudEl.innerHTML = '';

    // Collect all tags with their associated shortcuts
    let tagMap = {}; // { tagName: [{ name, url }, ...] }
    keys.forEach(function (key) {
      let data = items[key];
      let tags = typeof data === 'object' && Array.isArray(data.tags) ? data.tags : [];
      let url = typeof data === 'object' ? (data.url || '') : (data || '');
      tags.forEach(function (t) {
        if (!tagMap[t]) tagMap[t] = [];
        tagMap[t].push({ name: key, url: url });
      });
    });

    let tagNames = Object.keys(tagMap).sort((a, b) => tagMap[b].length - tagMap[a].length);

    if (tagNames.length === 0) {
      tagCloudEl.innerHTML = '<p style="color:var(--text-muted);padding:12px 0;">No tags yet.</p>';
    } else {
      // Create a single shared tooltip element at the document body level
      let sharedTooltip = document.getElementById('tagCloudTooltip');
      if (!sharedTooltip) {
        sharedTooltip = document.createElement('div');
        sharedTooltip.id = 'tagCloudTooltip';
        sharedTooltip.className = 'stats-cloud-tooltip';
        document.body.appendChild(sharedTooltip);
      }
      sharedTooltip.classList.remove('visible');

      let maxTagCount = tagMap[tagNames[0]].length;

      tagNames.forEach(function (tagName) {
        let count = tagMap[tagName].length;
        let scale = maxTagCount > 1 ? (count - 1) / (maxTagCount - 1) : 0;
        let fontSize = Math.round(13 + scale * 15);

        let pill = document.createElement('span');
        pill.className = 'stats-cloud-tag';
        pill.style.fontSize = fontSize + 'px';
        pill.innerHTML = escapeHtml(tagName) + ' <span class="stats-cloud-count">' + count + '</span>';

        // Build tooltip HTML for this tag
        let tooltipHtml = '<div class="stats-cloud-tooltip-title">' + escapeHtml(tagName) + ' (' + count + ')</div>';
        tagMap[tagName].slice(0, 10).forEach(function (bm) {
          let favSrc = 'icon16.png';
          try { favSrc = 'https://www.google.com/s2/favicons?domain=' + new URL(bm.url).hostname + '&sz=16'; } catch (e) {}
          tooltipHtml += '<div class="stats-cloud-tooltip-item"><img width="12" height="12" src="' + favSrc + '"><span>' + escapeHtml(bm.name) + '</span></div>';
        });
        if (count > 10) {
          tooltipHtml += '<div class="stats-cloud-tooltip-more">+' + (count - 10) + ' more</div>';
        }

        pill.addEventListener('mouseenter', function () {
          sharedTooltip.innerHTML = tooltipHtml;
          sharedTooltip.classList.add('visible');
          // Position tooltip next to the pill
          let rect = pill.getBoundingClientRect();
          let ttWidth = 220;
          let left = rect.left + rect.width / 2 - ttWidth / 2;
          // Keep within viewport horizontally
          if (left < 8) left = 8;
          if (left + ttWidth > window.innerWidth - 8) left = window.innerWidth - ttWidth - 8;
          sharedTooltip.style.left = left + 'px';
          sharedTooltip.style.top = (rect.bottom + 8) + 'px';
          sharedTooltip.style.width = ttWidth + 'px';
        });

        pill.addEventListener('mouseleave', function () {
          sharedTooltip.classList.remove('visible');
        });

        tagCloudEl.appendChild(pill);
      });
    }

  } catch (err) {
    showToast('Error loading stats: ' + err.message, 'error');
  }
}

// Render timeline bar chart for daily/weekly/monthly
function renderTimeline(dailyStats, period) {
  let el = document.getElementById('statsTimeline');
  el.innerHTML = '';

  let now = new Date();
  let buckets = [];

  if (period === 'daily') {
    // Last 14 days
    for (let i = 13; i >= 0; i--) {
      let d = new Date(now);
      d.setDate(d.getDate() - i);
      let key = d.toISOString().slice(0, 10);
      let label = d.toLocaleDateString('en', { month: 'short', day: 'numeric' });
      buckets.push({ label: label, count: dailyStats[key] ? dailyStats[key].opens : 0 });
    }
  } else if (period === 'weekly') {
    // Last 8 weeks
    for (let w = 7; w >= 0; w--) {
      let weekStart = new Date(now);
      weekStart.setDate(weekStart.getDate() - (w * 7) - weekStart.getDay());
      let total = 0;
      for (let d = 0; d < 7; d++) {
        let day = new Date(weekStart);
        day.setDate(day.getDate() + d);
        let key = day.toISOString().slice(0, 10);
        if (dailyStats[key]) total += dailyStats[key].opens;
      }
      let label = weekStart.toLocaleDateString('en', { month: 'short', day: 'numeric' });
      buckets.push({ label: 'W/' + label, count: total });
    }
  } else {
    // Last 6 months
    for (let m = 5; m >= 0; m--) {
      let monthDate = new Date(now.getFullYear(), now.getMonth() - m, 1);
      let total = 0;
      let daysInMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0).getDate();
      for (let d = 1; d <= daysInMonth; d++) {
        let key = new Date(monthDate.getFullYear(), monthDate.getMonth(), d).toISOString().slice(0, 10);
        if (dailyStats[key]) total += dailyStats[key].opens;
      }
      buckets.push({ label: monthDate.toLocaleDateString('en', { month: 'short' }), count: total });
    }
  }

  let maxVal = Math.max(...buckets.map(b => b.count), 1);

  let chart = document.createElement('div');
  chart.className = 'timeline-chart';

  buckets.forEach(function (b) {
    let col = document.createElement('div');
    col.className = 'timeline-col';

    let bar = document.createElement('div');
    bar.className = 'timeline-bar';
    let height = Math.max((b.count / maxVal) * 120, 4);
    bar.style.height = height + 'px';
    if (b.count > 0) {
      bar.setAttribute('data-tooltip', b.count + ' opens');
    }

    let label = document.createElement('div');
    label.className = 'timeline-label';
    label.textContent = b.label;

    let countLabel = document.createElement('div');
    countLabel.className = 'timeline-count';
    countLabel.textContent = b.count > 0 ? b.count : '';

    col.appendChild(countLabel);
    col.appendChild(bar);
    col.appendChild(label);
    chart.appendChild(col);
  });

  el.appendChild(chart);
}

// ============================================================
// SETTINGS
// ============================================================
async function loadSettingsState() {
  try {
    let result = await storageGet('__ssg_settings');
    let settings = result['__ssg_settings'] || {};
    document.getElementById('settingBookmarkSync').checked = settings.bookmarkSync !== false;
    document.getElementById('settingTabGroupFolders').checked = settings.tabGroupFolders !== false;

    // AI settings — opt-in (default off), never disable the toggle itself
    let aiToggle = document.getElementById('settingAiFeatures');
    if (aiToggle) {
      aiToggle.checked = settings.aiEnabled === true;
      // Check actual AI availability and show status text
      chrome.runtime.sendMessage({ action: 'ai:status' }, function (response) {
        if (chrome.runtime.lastError) return;
        let statusEl = document.getElementById('aiStatusText');
        if (statusEl && response) {
          if (response.status === 'readily') {
            statusEl.textContent = 'Gemini Nano is ready';
            statusEl.style.color = 'var(--success)';
          } else if (response.status === 'after-download') {
            statusEl.textContent = 'Model available (needs download)';
            statusEl.style.color = 'var(--accent)';
          } else {
            statusEl.textContent = 'Not available on this browser';
            statusEl.style.color = 'var(--text-muted)';
            // Don't disable the toggle — the change handler will prevent enabling
            // but the user should always be able to toggle off
          }
        }
      });
    }
  } catch (e) {}
}

document.getElementById('settingBookmarkSync').addEventListener('change', async function () {
  try {
    let result = await storageGet('__ssg_settings');
    let settings = result['__ssg_settings'] || {};
    settings.bookmarkSync = this.checked;
    await storageSet({ '__ssg_settings': settings });
    showToast('Bookmark sync ' + (this.checked ? 'enabled' : 'disabled'), 'success');
  } catch (e) {
    showToast('Error saving setting.', 'error');
  }
});

// Tab group folders toggle
document.getElementById('settingTabGroupFolders').addEventListener('change', async function () {
  try {
    let result = await storageGet('__ssg_settings');
    let settings = result['__ssg_settings'] || {};
    settings.tabGroupFolders = this.checked;
    await storageSet({ '__ssg_settings': settings });
    showToast('Tab groups ' + (this.checked ? 'enabled' : 'disabled'), 'success');
  } catch (e) {
    showToast('Error saving setting.', 'error');
  }
});

// AI features toggle — prevent enabling when browser doesn't support it
let aiToggleGlobal = document.getElementById('settingAiFeatures');
if (aiToggleGlobal) {
  aiToggleGlobal.addEventListener('change', async function () {
    let toggle = this;
    try {
      if (toggle.checked) {
        // Check AI availability before allowing enable
        let aiStatus = await new Promise(function (resolve) {
          let timeout = setTimeout(function () { resolve({ available: false, status: 'no' }); }, 3000);
          chrome.runtime.sendMessage({ action: 'ai:status' }, function (r) {
            clearTimeout(timeout);
            if (chrome.runtime.lastError) { resolve({ available: false, status: 'no' }); return; }
            resolve(r || { available: false, status: 'no' });
          });
        });
        if (!aiStatus.available) {
          toggle.checked = false;
          let reason = 'Your browser does not support Gemini Nano.';
          if (aiStatus.status === 'after-download') {
            reason = 'Gemini Nano model needs to be downloaded first. Visit chrome://flags/#optimization-guide-on-device-model and enable it, then restart Chrome.';
          } else {
            reason = 'Gemini Nano is not available. Make sure you are using Chrome 127+ with chrome://flags/#prompt-api-for-gemini-nano enabled.';
          }
          showToast(reason, 'error');
          return;
        }
      }
      let result = await storageGet('__ssg_settings');
      let settings = result['__ssg_settings'] || {};
      settings.aiEnabled = toggle.checked;
      await storageSet({ '__ssg_settings': settings });
      showToast('AI features ' + (toggle.checked ? 'enabled' : 'disabled'), 'success');
    } catch (e) {
      showToast('Error saving setting.', 'error');
    }
  });
}

// ============================================================
// ADD NEW BOOKMARK / ADD NEW FOLDER buttons
// ============================================================
document.getElementById('addNewBookmarkBtn').addEventListener('click', function () {
  chrome.runtime.sendMessage({ action: 'getBookmarkFolders' }, function (folders) {
    folders = folders || [];
    let folderSelectData = folders.map(function (f) {
      let indent = '';
      for (let i = 0; i < f.depth; i++) indent += '\u00A0\u00A0';
      return { value: f.id, label: indent + (f.title || '(Untitled)') };
    });

    let addBmTagsConf = { id: 'tags', tags: [] };
    showModal({
      title: 'Add Bookmark',
      inputs: [
        { id: 'url', label: 'URL', value: '', placeholder: 'https://example.com' },
        { id: 'bmname', label: 'Bookmark Name', value: '', placeholder: 'e.g. Book Fusion' },
        { id: 'shortcut', label: 'Tab0 Shortcut (lowercase, no spaces)', value: '', placeholder: 'e.g. bookfusion' },
        { id: 'folder', label: 'Bookmark Folder', type: 'select', selectOptions: folderSelectData, value: '' },
        { id: 'tags', label: 'Tags (up to 5, press Enter to add)', type: 'tags' }
      ],
      _tagsInputs: [addBmTagsConf],
      afterRender: function () {
        let urlInput = document.getElementById('dm-input-url');
        if (urlInput) {
          urlInput.addEventListener('blur', function () {
            let urlVal = urlInput.value.trim();
            if (!urlVal) return;
            if (!/^https?:\/\//i.test(urlVal)) urlVal = 'https://' + urlVal;
            let nameField = document.getElementById('dm-input-bmname');
            let shortcutField = document.getElementById('dm-input-shortcut');
            try {
              let hostname = new URL(urlVal).hostname.replace(/^www\./, '');
              let domain = hostname.split('.')[0];
              if (nameField && !nameField.value.trim()) nameField.value = domain.charAt(0).toUpperCase() + domain.slice(1);
              if (shortcutField && !shortcutField.value.trim()) shortcutField.value = domain.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 15);
            } catch (e) {}

            // Auto-generate basic tags immediately
            let bmTitle = (nameField ? nameField.value : '') || '';
            if (addBmTagsConf.instance && addBmTagsConf.instance.getTags().length === 0) {
              let basicTags = generateTagsFromBookmark(bmTitle, urlVal);
              basicTags.forEach(function (t) { addBmTagsConf.instance.addTag(t); });
            }

            // Try AI-powered generation (fills in asynchronously)
            chrome.runtime.sendMessage({ action: 'ai:generateTags', title: bmTitle, url: urlVal }, function (r) {
              if (chrome.runtime.lastError || !r || !r.tags) return;
              if (addBmTagsConf.instance) {
                let current = addBmTagsConf.instance.getTags();
                r.tags.forEach(function (t) {
                  if (current.length < 5 && !current.includes(t)) {
                    addBmTagsConf.instance.addTag(t);
                    current.push(t);
                  }
                });
              }
            });
            chrome.runtime.sendMessage({ action: 'ai:generateShortcutName', title: bmTitle, url: urlVal }, function (r) {
              if (chrome.runtime.lastError || !r || !r.name) return;
              if (shortcutField && !shortcutField.value.trim()) {
                shortcutField.value = r.name;
                shortcutField.style.borderColor = 'var(--accent)';
                setTimeout(function () { shortcutField.style.borderColor = ''; }, 2000);
              }
            });
          });
        }
      },
      buttons: [
        { text: 'Cancel', className: 'dm-btn-cancel' },
        {
          text: 'Save', className: 'dm-btn-save', onClick: async function () {
            let name = document.getElementById('dm-input-bmname').value.trim();
            let shortcutInput = document.getElementById('dm-input-shortcut').value.trim().toLowerCase().replace(/\s+/g, '');
            let url = document.getElementById('dm-input-url').value.trim();
            let folderId = document.getElementById('dm-input-folder').value;
            let tags = addBmTagsConf.instance ? addBmTagsConf.instance.getTags() : [];
            if (!name) { showToast('Name required.', 'error'); return; }
            if (!url || !isSaveableUrl(url)) { showToast('Valid URL required.', 'error'); return; }
            // Auto-generate tags if none were added
            if (tags.length === 0) tags = generateTagsFromBookmark(name, url);
            let shortcutName = shortcutInput || name.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 15);
            if (shortcutName && shortcutName.length > 15) { showToast('Shortcut name too long (max 15).', 'error'); return; }
            let createData = { title: name, url: url };
            if (folderId) createData.parentId = folderId;
            chrome.bookmarks.create(createData, function (newBm) {
              if (chrome.runtime.lastError) {
                showToast('Error: ' + chrome.runtime.lastError.message, 'error');
                return;
              }
              if (shortcutName) {
                storageGet(null).then(function (all) {
                  if (all[shortcutName] && isShortcutKey(shortcutName)) {
                    showToast('Bookmark added! Shortcut "' + shortcutName + '" already exists.', 'info');
                  } else {
                    storageSet({ [shortcutName]: { url: url, count: 0, bookmarkId: newBm.id, bookmarkTitle: name, tags: tags, createdAt: Date.now() } }).then(function () {
                      showToast('Bookmark & shortcut added!', 'success');
                    });
                  }
                });
              } else {
                showToast('Bookmark added!', 'success');
              }
              loadBookmarksView(true);
              if (openPanels.length > 0) refreshOpenPanels();
            });
          }
        }
      ]
    });
  });
});

document.getElementById('addNewFolderBtn').addEventListener('click', function () {
  chrome.runtime.sendMessage({ action: 'getBookmarkFolders' }, function (folders) {
    folders = folders || [];
    let folderSelectData = folders.map(function (f) {
      let indent = '';
      for (let i = 0; i < f.depth; i++) indent += '\u00A0\u00A0';
      return { value: f.id, label: indent + (f.title || '(Untitled)') };
    });

    // Default to Bookmarks bar (ID "1" in Chrome)
    let defaultParentId = '1';

    showModal({
      title: 'Add Folder',
      inputs: [
        { id: 'foldername', label: 'FOLDER NAME', value: '', placeholder: 'New folder name' },
        { id: 'parent', label: 'PARENT FOLDER', type: 'select', selectOptions: folderSelectData, value: defaultParentId }
      ],
      buttons: [
        { text: 'Cancel', className: 'dm-btn-cancel' },
        {
          text: 'Create', className: 'dm-btn-save', onClick: function () {
            let name = document.getElementById('dm-input-foldername').value.trim();
            let parentId = document.getElementById('dm-input-parent').value;
            if (!name) { showToast('Folder name required.', 'error'); return; }
            let createData = { title: name };
            if (parentId) createData.parentId = parentId;
            chrome.bookmarks.create(createData, function () {
              if (chrome.runtime.lastError) {
                showToast('Error: ' + chrome.runtime.lastError.message, 'error');
                return;
              }
              showToast('Folder created!', 'success');
              loadBookmarksView(true);
              if (openPanels.length > 0) refreshOpenPanels();
            });
          }
        }
      ]
    });
  });
});

// Shortcut filter change handler
document.getElementById('shortcutFilter').addEventListener('change', function () {
  loadShortcutsTable();
});

// ============================================================
// CSV IMPORT/EXPORT (now under Settings)
// ============================================================
document.getElementById('dashExportBtn').addEventListener('click', async function () {
  try {
    let items = await storageGet(null);
    let keys = Object.keys(items).filter(isShortcutKey);
    if (keys.length === 0) { showToast('No shortcuts to export.', 'error'); return; }

    let csvContent = 'shortcut_name,url,count,folder\n';
    keys.forEach(function (key) {
      let data = items[key];
      let url = typeof data === 'object' ? data.url : data;
      let count = typeof data === 'object' ? (data.count || 0) : 0;
      let folder = typeof data === 'object' ? (data.folder || data.category || '') : '';
      csvContent += key + ',"' + url.replace(/"/g, '""') + '",' + count + ',"' + folder.replace(/"/g, '""') + '"\n';
    });

    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    let downloadUrl = URL.createObjectURL(blob);
    let a = document.createElement('a');
    a.href = downloadUrl;
    a.download = 'tab0-shortcuts.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(downloadUrl);
    showToast('CSV exported!', 'success');
  } catch (err) {
    showToast('Export error: ' + err.message, 'error');
  }
});

document.getElementById('dashImportBtn').addEventListener('click', function () {
  document.getElementById('dashCsvInput').click();
});

document.getElementById('dashCsvInput').addEventListener('change', function (event) {
  let file = event.target.files[0];
  if (!file) return;

  let reader = new FileReader();
  reader.onload = async function (e) {
    let text = e.target.result;
    let lines = text.split('\n').filter(l => l.trim() !== '');
    let startIndex = (lines.length > 0 && lines[0].toLowerCase().includes('shortcut_name')) ? 1 : 0;

    if (lines.length <= startIndex) { showToast('CSV is empty.', 'error'); return; }

    let shortcuts = {};
    let skipped = 0;

    for (let i = startIndex; i < lines.length; i++) {
      let line = lines[i].trim();
      if (!line) continue;

      let parts;
      if (line.includes('"')) {
        let match = line.match(/^([^,]+),("(?:[^"]|"")*"|[^,]*),?([^,]*),?(.*)$/);
        if (match) {
          parts = [
            match[1].trim().toLowerCase(),
            match[2].replace(/^"|"$/g, '').replace(/""/g, '"').trim(),
            parseInt(match[3]) || 0,
            match[4] ? match[4].replace(/^"|"$/g, '').replace(/""/g, '"').trim() : ''
          ];
        } else { skipped++; continue; }
      } else {
        let split = line.split(',');
        parts = [
          split[0] ? split[0].trim().toLowerCase() : '',
          split[1] ? split[1].trim() : '',
          parseInt(split[2]) || 0,
          split[3] ? split[3].trim() : ''
        ];
      }

      if (!parts[0] || !parts[1] || parts[0].length > 15 || /\s/.test(parts[0])) { skipped++; continue; }
      shortcuts[parts[0]] = { url: parts[1], count: parts[2], folder: parts[3] };
    }

    let count = Object.keys(shortcuts).length;
    if (count === 0) { showToast('No valid shortcuts in CSV.', 'error'); return; }

    showModal({
      title: 'Import CSV',
      body: 'Import ' + count + ' shortcut(s)?' + (skipped > 0 ? ' (' + skipped + ' rows skipped)' : '') + ' Existing names will be overwritten.',
      buttons: [
        { text: 'Cancel', className: 'dm-btn-cancel' },
        {
          text: 'Import', className: 'dm-btn-save', onClick: async function () {
            try {
              await storageSet(shortcuts);
              showToast(count + ' shortcut(s) imported!', 'success');
              let resultEl = document.getElementById('dashImportResult');
              resultEl.className = 'result-msg result-success';
              resultEl.textContent = count + ' shortcuts imported!';
              resultEl.classList.remove('hidden');
              loadShortcutsTable();
            } catch (err) {
              showToast('Import error: ' + err.message, 'error');
            }
          }
        }
      ]
    });
  };
  reader.readAsText(file);
  event.target.value = '';
});

// ============================================================
// BOOKMARKS - Gallery View + Drag & Drop + Live Sync
// ============================================================
let allBookmarkNodes = [];
let currentOpenFolder = null; // still track for compatibility
let openPanels = []; // Array of {id, folderNode} for multi-panel

function getBookmarkTree() {
  return new Promise((resolve) => {
    chrome.bookmarks.getTree((tree) => resolve(tree));
  });
}

function flattenBookmarks(node, arr) {
  if (node.url) arr.push(node);
  if (node.children) node.children.forEach(child => flattenBookmarks(child, arr));
}

function countBookmarks(node) {
  let total = 0;
  if (node.url) total++;
  if (node.children) node.children.forEach(function (c) { total += countBookmarks(c); });
  return total;
}

async function loadBookmarksView(keepPanels) {
  let grid = document.getElementById('bmGalleryGrid');
  let emptyEl = document.getElementById('bookmarksEmpty');
  grid.innerHTML = '';
  emptyEl.classList.add('hidden');

  if (!keepPanels) {
    closeFolderDetail();
    currentOpenFolder = null;
  }

  try {
    let tree = await getBookmarkTree();
    window._tab0CachedTree = tree;
    allBookmarkNodes = [];

    let roots = tree[0].children || [];
    let hasContent = false;

    roots.forEach(function (rootFolder) {
      flattenBookmarks(rootFolder, allBookmarkNodes);
      if (!rootFolder.children || rootFolder.children.length === 0) return;
      hasContent = true;

      let card = renderGalleryCard(rootFolder);
      grid.appendChild(card);

      let subfolders = rootFolder.children.filter(c => !c.url && c.children && c.children.length > 0);
      subfolders.forEach(function (sub) {
        let subCard = renderGalleryCard(sub);
        grid.appendChild(subCard);
      });
    });

    if (!hasContent) emptyEl.classList.remove('hidden');
  } catch (err) {
    showToast('Error loading bookmarks: ' + err.message, 'error');
  }
}

// Check if targetId is a descendant of parentId in the cached tree
function isDescendantOf(targetId, ancestorId) {
  let tree = window._tab0CachedTree;
  if (!tree) return false;
  function findNode(node, id) {
    if (node.id === id) return node;
    if (node.children) {
      for (let c of node.children) {
        let found = findNode(c, id);
        if (found) return found;
      }
    }
    return null;
  }
  let ancestor = findNode(tree[0], ancestorId);
  if (!ancestor) return false;
  function hasDescendant(node, id) {
    if (node.id === id) return true;
    if (node.children) {
      for (let c of node.children) {
        if (hasDescendant(c, id)) return true;
      }
    }
    return false;
  }
  return hasDescendant(ancestor, targetId);
}

function renderGalleryCard(folderNode) {
  let card = document.createElement('div');
  card.className = 'bm-gallery-card';
  card.setAttribute('data-folder-id', folderNode.id);
  card.setAttribute('draggable', 'true');

  // --- Drag start: make this folder card draggable ---
  card.addEventListener('dragstart', function (e) {
    e.dataTransfer.setData('text/bookmark-id', folderNode.id);
    e.dataTransfer.setData('text/is-folder', 'true');
    e.dataTransfer.effectAllowed = 'move';
    card.classList.add('bm-card-dragging');
    // Highlight other cards as drop targets
    setTimeout(function () {
      document.querySelectorAll('.bm-gallery-card').forEach(function (c) {
        if (c.getAttribute('data-folder-id') !== folderNode.id) {
          c.classList.add('bm-drag-hint');
        }
      });
    }, 0);
  });
  card.addEventListener('dragend', function () {
    card.classList.remove('bm-card-dragging');
    document.querySelectorAll('.bm-gallery-card').forEach(c => c.classList.remove('bm-drag-hint', 'bm-drop-target'));
  });

  // --- Drop target: accept folders/bookmarks dropped into this card ---
  card.addEventListener('dragover', function (e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (!card.classList.contains('bm-card-dragging')) {
      card.classList.add('bm-drop-target');
    }
  });
  card.addEventListener('dragleave', function () {
    card.classList.remove('bm-drop-target');
  });
  card.addEventListener('drop', function (e) {
    e.preventDefault();
    card.classList.remove('bm-drop-target');
    let bmId = e.dataTransfer.getData('text/bookmark-id');
    // Prevent dropping a folder into itself or into its own descendant
    if (bmId && bmId !== folderNode.id && !isDescendantOf(folderNode.id, bmId)) {
      chrome.runtime.sendMessage({
        action: 'moveBookmark', id: bmId, parentId: folderNode.id
      }, function () {
        loadBookmarksView(true);
        if (openPanels.length > 0) refreshOpenPanels();
      });
    }
  });

  let header = document.createElement('div');
  header.className = 'bm-gallery-header';
  let folderIcon = document.createElement('span');
  folderIcon.className = 'bm-gallery-icon';
  folderIcon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';
  header.appendChild(folderIcon);
  let title = document.createElement('span');
  title.className = 'bm-gallery-title';
  title.textContent = folderNode.title || 'Bookmarks';
  header.appendChild(title);
  card.appendChild(header);

  let preview = document.createElement('div');
  preview.className = 'bm-gallery-preview';
  let directBookmarks = (folderNode.children || []).filter(c => c.url);
  let directFolders = (folderNode.children || []).filter(c => !c.url && c.children);
  let previewItems = directBookmarks.slice(0, 5);

  previewItems.forEach(function (bm) {
    let item = document.createElement('div');
    item.className = 'bm-gallery-preview-item';
    item.appendChild(createFaviconEl(bm.url, bm.title || bm.url, '', 14));
    let name = document.createElement('span');
    name.textContent = bm.title || bm.url;
    item.appendChild(name);
    preview.appendChild(item);
  });

  if (directFolders.length > 0) {
    let foldersLine = document.createElement('div');
    foldersLine.className = 'bm-gallery-preview-item bm-gallery-subfolder-line';
    foldersLine.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';
    let ftext = document.createElement('span');
    ftext.textContent = directFolders.length + ' subfolder' + (directFolders.length !== 1 ? 's' : '');
    foldersLine.appendChild(ftext);
    preview.appendChild(foldersLine);
  }

  if (directBookmarks.length > 5) {
    let more = document.createElement('div');
    more.className = 'bm-gallery-more';
    more.textContent = '+ ' + (directBookmarks.length - 5) + ' more';
    preview.appendChild(more);
  }

  if (directBookmarks.length === 0 && directFolders.length === 0) {
    let empty = document.createElement('div');
    empty.className = 'bm-gallery-empty';
    empty.textContent = 'Empty folder';
    preview.appendChild(empty);
  }

  card.appendChild(preview);

  let footer = document.createElement('div');
  footer.className = 'bm-gallery-footer';
  let total = countBookmarks(folderNode);
  footer.textContent = total + ' bookmark' + (total !== 1 ? 's' : '');
  card.appendChild(footer);

  let wasDragged = false;
  card.addEventListener('dragstart', function () { wasDragged = true; });
  card.addEventListener('dragend', function () { setTimeout(function () { wasDragged = false; }, 100); });
  card.addEventListener('click', function () {
    if (wasDragged) return;
    openFolderDetail(folderNode);
  });

  return card;
}

function updatePanelMargin() {
  let main = document.querySelector('.main');
  main.classList.remove('panel-open-1', 'panel-open-2');
  if (openPanels.length === 1) main.classList.add('panel-open-1');
  else if (openPanels.length >= 2) main.classList.add('panel-open-2');
}

function closeFolderDetail() {
  let container = document.getElementById('bmPanelContainer');
  container.innerHTML = '';
  container.classList.add('hidden');
  openPanels = [];
  currentOpenFolder = null;
  updatePanelMargin();
}

// Close a specific panel by its index in the openPanels array
// Also closes any panels to its right (like miller columns)
function closePanelAt(index) {
  // Remove this panel and all panels to the right
  openPanels.splice(index);
  renderAllPanels();
}

function renderAllPanels() {
  let container = document.getElementById('bmPanelContainer');

  if (openPanels.length === 0) {
    container.innerHTML = '';
    container.classList.add('hidden');
    currentOpenFolder = null;
    updatePanelMargin();
    return;
  }

  container.classList.remove('hidden');
  currentOpenFolder = openPanels[openPanels.length - 1].folderNode;

  // Build all new panels off-screen first, then swap in one shot to avoid flicker
  let fragment = document.createDocumentFragment();
  openPanels.forEach(function (panelData, panelIndex) {
    let panel = buildPanelElement(panelData.folderNode, panelIndex);
    fragment.appendChild(panel);
  });
  container.innerHTML = '';
  container.appendChild(fragment);

  updatePanelMargin();
}

// Open folder detail: from gallery click → replace all panels; from subfolder click → add as next panel
function openFolderDetail(folderNode, options) {
  options = options || {};

  // Reduce max panels to 1 when chat side-panel is open
  let chatIsOpen = document.body.classList.contains('chat-panel-open');
  let maxPanels = chatIsOpen ? 1 : 2;

  if (options.asSubfolder && openPanels.length > 0) {
    // Opening a subfolder: close any panels after the parent panel, then add this one
    let parentIndex = options.parentPanelIndex !== undefined ? options.parentPanelIndex : openPanels.length - 1;
    // Remove panels after parent
    openPanels.splice(parentIndex + 1);
    // Add this subfolder as a new panel
    if (openPanels.length >= maxPanels) {
      // Replace the last panel
      openPanels[maxPanels - 1] = { id: folderNode.id, folderNode: folderNode };
    } else {
      openPanels.push({ id: folderNode.id, folderNode: folderNode });
    }
  } else {
    // Opening from gallery card: check if already open
    let existingIdx = openPanels.findIndex(p => p.id === folderNode.id);
    if (existingIdx >= 0) {
      // Already open, just refresh it
      openPanels[existingIdx].folderNode = folderNode;
    } else if (openPanels.length >= maxPanels) {
      // At max panels, replace the last one
      openPanels[maxPanels - 1] = { id: folderNode.id, folderNode: folderNode };
    } else {
      openPanels.push({ id: folderNode.id, folderNode: folderNode });
    }
  }

  currentOpenFolder = folderNode;
  renderAllPanels();
}

function refreshOpenPanels() {
  // Invalidate cached tree so breadcrumbs re-fetch after moves
  window._tab0CachedTree = null;
  // Pre-fetch the tree so it's ready synchronously when panels rebuild
  chrome.bookmarks.getTree(function (tree) {
    window._tab0CachedTree = tree;
  });
  // Refresh all open panels from their IDs
  let toRefresh = openPanels.map(p => p.id);
  let refreshed = 0;
  toRefresh.forEach(function (folderId, idx) {
    chrome.bookmarks.getSubTree(folderId, function (results) {
      if (results && results[0]) {
        openPanels[idx] = { id: folderId, folderNode: results[0] };
      }
      refreshed++;
      if (refreshed === toRefresh.length) {
        // Remove panels whose folders no longer exist
        openPanels = openPanels.filter(p => p.folderNode);
        renderAllPanels();
      }
    });
  });
}

// ============================================================
// FOLDER EXPORT
// ============================================================
async function exportBookmarksFromFolder(folderNode) {
  try {
    let bookmarks = (folderNode.children || []).filter(c => c.url);
    if (bookmarks.length === 0) {
      showToast('No bookmarks to export in this folder.', 'error');
      return;
    }

    // Also get Tab0 shortcut data for each bookmark
    let allData = await storageGet(null);
    let allKeys = Object.keys(allData).filter(isShortcutKey);

    let exportItems = bookmarks.map(function (bm) {
      // Find matching shortcut by bookmarkId
      let shortcutKey = '';
      let tags = [];
      for (let i = 0; i < allKeys.length; i++) {
        let d = allData[allKeys[i]];
        if (typeof d === 'object' && d.bookmarkId === bm.id) {
          shortcutKey = allKeys[i];
          tags = d.tags || [];
          break;
        }
      }
      return {
        title: bm.title || '',
        url: bm.url,
        shortcutName: shortcutKey,
        tags: tags
      };
    });

    let exportObj = {
      folderName: folderNode.title || 'Bookmarks',
      exportedAt: new Date().toISOString(),
      bookmarks: exportItems
    };

    let json = JSON.stringify(exportObj, null, 2);
    let blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
    let downloadUrl = URL.createObjectURL(blob);
    let a = document.createElement('a');
    a.href = downloadUrl;
    a.download = 'tab0-' + (folderNode.title || 'bookmarks').toLowerCase().replace(/[^a-z0-9]+/g, '-') + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(downloadUrl);
    showToast(bookmarks.length + ' bookmark(s) exported!', 'success');
  } catch (err) {
    showToast('Export error: ' + err.message, 'error');
  }
}

// ============================================================
// FOLDER IMPORT (with conflict resolution)
// ============================================================
function importBookmarksToFolder(folderNode) {
  // Create a hidden file input and trigger it
  let fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = '.json';
  fileInput.style.display = 'none';
  document.body.appendChild(fileInput);

  fileInput.addEventListener('change', function (event) {
    let file = event.target.files[0];
    if (!file) { document.body.removeChild(fileInput); return; }

    let reader = new FileReader();
    reader.onload = async function (e) {
      document.body.removeChild(fileInput);
      try {
        let data = JSON.parse(e.target.result);
        if (!data.bookmarks || !Array.isArray(data.bookmarks) || data.bookmarks.length === 0) {
          showToast('No bookmarks found in file.', 'error');
          return;
        }

        let incoming = data.bookmarks.filter(b => b.url && isSaveableUrl(b.url));
        if (incoming.length === 0) {
          showToast('No valid bookmarks in file.', 'error');
          return;
        }

        // Check for conflicts: same shortcut name or same URL already in the folder
        let allData = await storageGet(null);
        let allKeys = Object.keys(allData).filter(isShortcutKey);
        let existingBookmarks = (folderNode.children || []).filter(c => c.url);

        let conflicts = [];
        let clean = [];

        incoming.forEach(function (item) {
          let nameConflict = item.shortcutName && allKeys.includes(item.shortcutName);
          let urlConflict = existingBookmarks.some(bm => bm.url === item.url);
          if (nameConflict || urlConflict) {
            conflicts.push({ item: item, nameConflict: nameConflict, urlConflict: urlConflict });
          } else {
            clean.push(item);
          }
        });

        if (conflicts.length === 0) {
          // No conflicts, just import all
          await doFolderImport(clean, [], folderNode, 'replace');
        } else {
          // Show conflict resolution modal
          showConflictModal(conflicts, clean, folderNode, allData, allKeys);
        }
      } catch (err) {
        showToast('Invalid file: ' + err.message, 'error');
      }
    };
    reader.readAsText(file);
  });

  fileInput.click();
}

function showConflictModal(conflicts, clean, folderNode, allData, allKeys) {
  // Build a display of conflicts
  let conflictHtml = '<div class="conflict-list">';
  conflicts.forEach(function (c) {
    let reasons = [];
    if (c.nameConflict) reasons.push('shortcut "' + escapeHtml(c.item.shortcutName) + '" exists');
    if (c.urlConflict) reasons.push('URL already in folder');
    conflictHtml += '<div class="conflict-item">' +
      '<span class="conflict-item-name">' + escapeHtml(c.item.title || c.item.shortcutName || 'Untitled') + '</span>' +
      '<span class="conflict-item-url">' + reasons.join(', ') + '</span>' +
      '</div>';
  });
  conflictHtml += '</div>';

  showModal({
    title: 'Import Conflicts',
    body: conflicts.length + ' of ' + (conflicts.length + clean.length) + ' bookmark(s) have conflicts:',
    buttons: [
      {
        text: 'Replace', className: 'dm-btn-danger', onClick: async function () {
          await doFolderImport(clean, conflicts, folderNode, 'replace');
        }
      },
      {
        text: 'Keep Both', className: 'dm-btn-save', onClick: async function () {
          await doFolderImport(clean, conflicts, folderNode, 'keep');
        }
      },
      { text: 'Cancel', className: 'dm-btn-cancel' }
    ]
  });

  // Inject the conflict list HTML into the modal body after it renders
  setTimeout(function () {
    let bodyEl = document.getElementById('dashModalBody');
    if (bodyEl) {
      bodyEl.innerHTML = escapeHtml(bodyEl.textContent) + conflictHtml;
    }
  }, 20);
}

async function doFolderImport(cleanItems, conflictItems, folderNode, mode) {
  // mode: 'replace' = overwrite existing shortcuts, 'keep' = rename shortcut with suffix
  try {
    let allData = await storageGet(null);
    let allKeys = Object.keys(allData).filter(isShortcutKey);
    let importCount = 0;

    // Helper: create a Chrome bookmark and Tab0 shortcut
    async function importOne(item, shortcutName) {
      // Create Chrome bookmark in the target folder
      let bm = await new Promise((resolve, reject) => {
        chrome.bookmarks.create({
          title: item.title || shortcutName || 'Untitled',
          url: item.url,
          parentId: folderNode.id
        }, function (result) {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(result);
        });
      });

      // Create Tab0 shortcut if name provided
      if (shortcutName) {
        let shortcutData = {
          url: item.url,
          count: 0,
          tags: item.tags || generateTagsFromBookmark(item.title || '', item.url),
          bookmarkId: bm.id,
          bookmarkTitle: item.title || shortcutName,
          createdAt: Date.now()
        };
        await storageSet({ [shortcutName]: shortcutData });
      }
      importCount++;
    }

    // Import clean (no-conflict) items
    for (let i = 0; i < cleanItems.length; i++) {
      let item = cleanItems[i];
      await importOne(item, item.shortcutName || '');
    }

    // Import conflict items based on mode
    for (let i = 0; i < conflictItems.length; i++) {
      let c = conflictItems[i];
      let item = c.item;

      if (mode === 'replace') {
        // If URL conflict: remove existing bookmark with same URL in folder, then re-import
        if (c.urlConflict) {
          let existing = (folderNode.children || []).find(bm => bm.url === item.url);
          if (existing) {
            await new Promise((resolve) => {
              chrome.bookmarks.remove(existing.id, function () {
                if (chrome.runtime.lastError) { /* ignore */ }
                resolve();
              });
            });
          }
        }

        // If name conflict: remove existing shortcut data
        if (c.nameConflict && item.shortcutName) {
          await storageRemove(item.shortcutName);
        }

        await importOne(item, item.shortcutName || '');
      } else if (mode === 'keep') {
        // Keep both: add the bookmark (even if URL duplicate in folder)
        // For shortcut name conflict: append a number suffix
        let baseName = item.shortcutName || '';
        let finalName = baseName;
        if (baseName && allKeys.includes(baseName)) {
          let suffix = 1;
          while (allKeys.includes(baseName + suffix) || (await storageGet(baseName + suffix))[baseName + suffix]) {
            suffix++;
          }
          finalName = baseName + suffix;
        }
        await importOne(item, finalName);
        // Track the new key so subsequent conflicts don't collide
        if (finalName) allKeys.push(finalName);
      }
    }

    showToast(importCount + ' bookmark(s) imported!', 'success');
    refreshOpenPanels();
    loadBookmarksView(true);
    loadShortcutsTable();
  } catch (err) {
    showToast('Import error: ' + err.message, 'error');
  }
}

function renderSubfolderCard(sub, container, parentFolderNode, panelIndex) {
  let subCard = document.createElement('div');
  subCard.className = 'bm-detail-subfolder';
  subCard.setAttribute('draggable', 'true');
  subCard.setAttribute('data-folder-drag-id', sub.id);

  subCard.addEventListener('click', function () {
    if (subCard.classList.contains('bm-was-dragging')) {
      subCard.classList.remove('bm-was-dragging');
      return;
    }
    chrome.bookmarks.getSubTree(sub.id, function (results) {
      if (results && results[0]) {
        openFolderDetail(results[0], { asSubfolder: true, parentPanelIndex: panelIndex });
      }
    });
  });

  // Make subfolder draggable
  subCard.addEventListener('dragstart', function (e) {
    e.stopPropagation();
    e.dataTransfer.setData('text/bookmark-id', sub.id);
    e.dataTransfer.setData('text/is-folder', 'true');
    e.dataTransfer.effectAllowed = 'move';
    subCard.classList.add('bm-dragging');
    document.querySelectorAll('.bm-detail-dropzone').forEach(z => z.classList.add('bm-drop-visible'));
    document.querySelectorAll('.bm-gallery-card').forEach(c => c.classList.add('bm-drag-hint'));
  });
  subCard.addEventListener('dragend', function () {
    if (subCard.classList.contains('bm-dragging')) {
      subCard.classList.remove('bm-dragging');
      subCard.classList.add('bm-was-dragging');
      setTimeout(() => subCard.classList.remove('bm-was-dragging'), 100);
    }
    document.querySelectorAll('.bm-detail-dropzone').forEach(z => z.classList.remove('bm-drop-visible'));
    document.querySelectorAll('.bm-drop-target').forEach(z => z.classList.remove('bm-drop-target'));
    document.querySelectorAll('.bm-gallery-card').forEach(c => c.classList.remove('bm-drag-hint'));
    document.querySelectorAll('.bm-drop-above, .bm-drop-below').forEach(z => z.classList.remove('bm-drop-above', 'bm-drop-below'));
  });

  // Accept drops (bookmarks/folders dropped INTO this subfolder)
  subCard.addEventListener('dragover', function (e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    subCard.classList.add('bm-drop-target');
  });
  subCard.addEventListener('dragleave', function () {
    subCard.classList.remove('bm-drop-target');
  });
  subCard.addEventListener('drop', function (e) {
    e.preventDefault();
    e.stopPropagation();
    subCard.classList.remove('bm-drop-target');
    let bmId = e.dataTransfer.getData('text/bookmark-id');
    if (bmId && bmId !== sub.id && !isDescendantOf(sub.id, bmId)) {
      chrome.runtime.sendMessage({ action: 'moveBookmark', id: bmId, parentId: sub.id }, function () {
        refreshOpenPanels();
        loadBookmarksView(true);
      });
    }
  });

  // Drag handle
  let dragHandle = document.createElement('div');
  dragHandle.className = 'bm-drag-handle bm-subfolder-drag-handle';
  dragHandle.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="5" r="1.5"/><circle cx="15" cy="5" r="1.5"/><circle cx="9" cy="12" r="1.5"/><circle cx="15" cy="12" r="1.5"/><circle cx="9" cy="19" r="1.5"/><circle cx="15" cy="19" r="1.5"/></svg>';
  subCard.appendChild(dragHandle);

  let folderSvg = document.createElement('span');
  folderSvg.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';
  subCard.appendChild(folderSvg);

  let nameSpan = document.createElement('span');
  nameSpan.className = 'bm-detail-subfolder-name';
  nameSpan.textContent = sub.title;
  subCard.appendChild(nameSpan);

  let countEl = document.createElement('span');
  countEl.className = 'bm-detail-subfolder-count';
  countEl.textContent = countBookmarks(sub);
  subCard.appendChild(countEl);

  let chevron = document.createElement('span');
  chevron.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>';
  subCard.appendChild(chevron);

  container.appendChild(subCard);
}

function buildPanelElement(folderNode, panelIndex) {
  let panel = document.createElement('div');
  panel.className = 'bm-detail-panel';
  panel.setAttribute('data-panel-index', panelIndex);

  // Header
  let header = document.createElement('div');
  header.className = 'bm-detail-panel-header';

  let titleArea = document.createElement('div');
  titleArea.className = 'bm-detail-title-area';
  titleArea.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';

  let h2 = document.createElement('h2');
  h2.textContent = folderNode.title || 'Bookmarks';
  titleArea.appendChild(h2);

  let total = countBookmarks(folderNode);
  let countSpan = document.createElement('span');
  countSpan.className = 'bm-detail-count';
  countSpan.textContent = total + ' bookmark' + (total !== 1 ? 's' : '');
  titleArea.appendChild(countSpan);

  header.appendChild(titleArea);

  // Shortcut badge — populated async, sits next to count
  let shortcutBadge = document.createElement('span');
  shortcutBadge.className = 'bm-detail-shortcut-badge';
  shortcutBadge.id = 'folderShortcutBadge-' + panelIndex;
  titleArea.appendChild(shortcutBadge);

  // Populate shortcut badge async
  populateFolderShortcutBadge(folderNode, panelIndex);

  // Header actions: more menu + close
  let headerActions = document.createElement('div');
  headerActions.className = 'bm-detail-header-actions';

  // More button (3 dots)
  let moreWrapper = document.createElement('div');
  moreWrapper.className = 'bm-more-wrapper';
  let moreBtn = document.createElement('button');
  moreBtn.className = 'bm-detail-action-icon bm-more-btn';
  moreBtn.title = 'More actions';
  moreBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>';

  // Dropdown menu
  let dropdown = document.createElement('div');
  dropdown.className = 'bm-more-dropdown';

  let menuItems = [
    { label: 'Edit', icon: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>', action: function () { openFolderEditModal(folderNode, panelIndex); } },
    { label: 'Import', icon: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>', action: function () { importBookmarksToFolder(folderNode); } },
    { label: 'Export', icon: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>', action: function () { exportBookmarksFromFolder(folderNode); } },
    { label: 'Delete', icon: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>', danger: true, action: function () { confirmDeleteFolder(folderNode, panelIndex); } }
  ];

  menuItems.forEach(function (item) {
    let menuItem = document.createElement('button');
    menuItem.className = 'bm-more-item' + (item.danger ? ' bm-more-item-danger' : '');
    menuItem.innerHTML = item.icon + '<span>' + item.label + '</span>';
    menuItem.addEventListener('click', function (e) {
      e.stopPropagation();
      dropdown.classList.remove('visible');
      item.action();
    });
    dropdown.appendChild(menuItem);
  });

  moreBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    // Close any other open dropdowns
    document.querySelectorAll('.bm-more-dropdown.visible').forEach(function (d) {
      if (d !== dropdown) d.classList.remove('visible');
    });
    dropdown.classList.toggle('visible');
  });

  moreWrapper.appendChild(moreBtn);
  moreWrapper.appendChild(dropdown);
  headerActions.appendChild(moreWrapper);

  // Close button
  let closeBtn = document.createElement('button');
  closeBtn.className = 'bm-detail-close';
  closeBtn.title = 'Close';
  closeBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
  closeBtn.addEventListener('click', function () {
    closePanelAt(panelIndex);
  });
  headerActions.appendChild(closeBtn);

  header.appendChild(headerActions);
  panel.appendChild(header);

  // Breadcrumb navigation — built synchronously from cached bookmark tree
  let breadcrumb = document.createElement('div');
  breadcrumb.className = 'bm-breadcrumb';

  // Walk the cached bookmark tree to find the path to this folder
  function findPathInTree(tree, targetId) {
    if (!tree) return null;
    if (tree.id === targetId) return [{ id: tree.id, title: tree.title || 'Bookmarks' }];
    if (tree.children) {
      for (let i = 0; i < tree.children.length; i++) {
        let result = findPathInTree(tree.children[i], targetId);
        if (result) {
          result.unshift({ id: tree.id, title: tree.title || 'Bookmarks' });
          return result;
        }
      }
    }
    return null;
  }

  // Use the cached tree from loadBookmarksView if available, otherwise fetch once
  function renderBreadcrumbFromTree(tree) {
    let path = null;
    if (tree && tree.length > 0) {
      // tree[0] is the root node
      path = findPathInTree(tree[0], folderNode.id);
    }
    if (!path || path.length <= 1) {
      // Just show current folder name
      let current = document.createElement('span');
      current.className = 'bm-breadcrumb-item bm-breadcrumb-current';
      current.textContent = folderNode.title || 'Bookmarks';
      breadcrumb.appendChild(current);
      return;
    }
    // Skip the invisible root node (id "0")
    let crumbs = path.filter(c => c.id !== '0');
    crumbs.forEach(function (crumb, idx) {
      if (idx > 0) {
        let sep = document.createElement('span');
        sep.className = 'bm-breadcrumb-sep';
        sep.textContent = '›';
        breadcrumb.appendChild(sep);
      }
      let link = document.createElement('span');
      link.className = 'bm-breadcrumb-item';
      link.textContent = crumb.title || 'Bookmarks';
      if (idx < crumbs.length - 1) {
        link.classList.add('bm-breadcrumb-link');
        link.addEventListener('click', function () {
          chrome.bookmarks.getSubTree(crumb.id, function (results) {
            if (results && results[0]) {
              openPanels[panelIndex] = { id: crumb.id, folderNode: results[0] };
              renderAllPanels();
            }
          });
        });
      } else {
        link.classList.add('bm-breadcrumb-current');
      }
      breadcrumb.appendChild(link);
    });
  }

  // Use cached tree if available, otherwise fetch synchronously-ish before appending
  if (window._tab0CachedTree) {
    renderBreadcrumbFromTree(window._tab0CachedTree);
  } else {
    chrome.bookmarks.getTree(function (tree) {
      window._tab0CachedTree = tree;
      renderBreadcrumbFromTree(tree);
    });
  }

  panel.appendChild(breadcrumb);

  // Content
  let content = document.createElement('div');
  content.className = 'bm-detail-content';

  if (!folderNode.children || folderNode.children.length === 0) {
    content.innerHTML = '<div class="bm-detail-empty">This folder is empty. Drag bookmarks here to add them.</div>';
    panel.appendChild(content);
    return panel;
  }

  // Render children in their original Chrome bookmark order (folders and bookmarks interleaved)
  folderNode.children.forEach(function (child) {
    if (child.url) {
      // It's a bookmark
      let row = renderDetailBookmarkItem(child, folderNode);
      content.appendChild(row);
    } else if (child.children) {
      // It's a subfolder — render inline
      let sub = child;
      renderSubfolderCard(sub, content, folderNode, panelIndex);
    }
  });

  let dropZone = document.createElement('div');
  dropZone.className = 'bm-detail-dropzone';
  dropZone.textContent = 'Drop bookmark here';
  dropZone.addEventListener('dragover', function (e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    dropZone.classList.add('bm-drop-active');
  });
  dropZone.addEventListener('dragleave', function () {
    dropZone.classList.remove('bm-drop-active');
  });
  dropZone.addEventListener('drop', function (e) {
    e.preventDefault();
    dropZone.classList.remove('bm-drop-active');
    let bmId = e.dataTransfer.getData('text/bookmark-id');
    if (bmId) {
      chrome.runtime.sendMessage({ action: 'moveBookmark', id: bmId, parentId: folderNode.id }, function () {
        refreshOpenPanels();
        loadBookmarksView(true);
      });
    }
  });
  content.appendChild(dropZone);

  panel.appendChild(content);
  return panel;
}

function renderDetailBookmarkItem(bm, parentFolder) {
  let row = document.createElement('div');
  row.className = 'bm-detail-item';
  row.setAttribute('draggable', 'true');
  row.setAttribute('data-bm-id', bm.id);
  row.setAttribute('data-bm-index', bm.index !== undefined ? bm.index : '');

  row.addEventListener('dragover', function (e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    let rect = row.getBoundingClientRect();
    let midY = rect.top + rect.height / 2;
    row.classList.remove('bm-drop-above', 'bm-drop-below');
    if (e.clientY < midY) row.classList.add('bm-drop-above');
    else row.classList.add('bm-drop-below');
  });
  row.addEventListener('dragleave', function () {
    row.classList.remove('bm-drop-above', 'bm-drop-below');
  });
  row.addEventListener('drop', function (e) {
    e.preventDefault();
    e.stopPropagation();
    row.classList.remove('bm-drop-above', 'bm-drop-below');
    let draggedId = e.dataTransfer.getData('text/bookmark-id');
    if (!draggedId || draggedId === bm.id) return;

    let rect = row.getBoundingClientRect();
    let midY = rect.top + rect.height / 2;
    let targetIndex = bm.index !== undefined ? bm.index : 0;
    if (e.clientY >= midY) targetIndex += 1;
    let targetParentId = parentFolder ? parentFolder.id : bm.parentId;

    chrome.runtime.sendMessage({
      action: 'moveBookmark', id: draggedId, parentId: targetParentId, index: targetIndex
    }, function () {
      if (openPanels.length > 0) {
        refreshOpenPanels();
      }
      loadBookmarksView(true);
    });
  });

  let handle = document.createElement('div');
  handle.className = 'bm-drag-handle';
  handle.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="5" r="1.5"/><circle cx="15" cy="5" r="1.5"/><circle cx="9" cy="12" r="1.5"/><circle cx="15" cy="12" r="1.5"/><circle cx="9" cy="19" r="1.5"/><circle cx="15" cy="19" r="1.5"/></svg>';
  row.appendChild(handle);

  row.appendChild(createFaviconEl(bm.url, bm.title || bm.url, 'bm-detail-favicon', 18));

  let info = document.createElement('div');
  info.className = 'bm-detail-info';

  let titleRow = document.createElement('div');
  titleRow.style.display = 'flex';
  titleRow.style.alignItems = 'center';
  titleRow.style.gap = '6px';

  let titleLink = document.createElement('a');
  titleLink.className = 'bm-detail-link';
  titleLink.href = bm.url;
  titleLink.target = '_blank';
  titleLink.textContent = bm.title || bm.url;
  titleLink.title = bm.url;
  titleLink.addEventListener('click', function (e) { e.stopPropagation(); });
  titleRow.appendChild(titleLink);

  // Add shortcut tag placeholder - will be filled async
  let shortcutTag = document.createElement('span');
  shortcutTag.className = 'bm-shortcut-tag';
  shortcutTag.style.display = 'none';
  titleRow.appendChild(shortcutTag);

  info.appendChild(titleRow);

  // Tags row placeholder
  let tagsRow = document.createElement('div');
  tagsRow.className = 'bm-detail-tags';
  tagsRow.style.display = 'none';

  // Look up the linked shortcut for this bookmark
  chrome.runtime.sendMessage({ action: 'getShortcutForBookmark', bookmarkId: bm.id }, function (response) {
    if (response && response.key) {
      shortcutTag.textContent = response.key;
      shortcutTag.style.display = 'inline-flex';
    }
    // Show tags
    let tags = (response && response.data && response.data.tags) ? response.data.tags : [];
    if (tags.length > 0) {
      tagsRow.style.display = 'flex';
      tags.forEach(function (tag) {
        let pill = document.createElement('span');
        pill.className = 'tag-pill';
        pill.textContent = tag;
        pill.setAttribute('data-tooltip', tag);
        tagsRow.appendChild(pill);
      });
    }
  });

  let urlText = document.createElement('span');
  urlText.className = 'bm-detail-url';
  urlText.textContent = bm.url.length > 70 ? bm.url.substring(0, 70) + '...' : bm.url;
  info.appendChild(urlText);
  info.appendChild(tagsRow);
  row.appendChild(info);

  let actions = document.createElement('div');
  actions.className = 'bm-detail-actions';

  let editBtn = document.createElement('button');
  editBtn.className = 'bm-detail-action-btn';
  editBtn.title = 'Edit bookmark';
  editBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>';
  editBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    editBookmark(bm);
  });
  actions.appendChild(editBtn);

  let deleteBtn = document.createElement('button');
  deleteBtn.className = 'bm-detail-action-btn bm-detail-action-delete';
  deleteBtn.title = 'Delete bookmark';
  deleteBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>';
  deleteBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    deleteBookmark(bm);
  });
  actions.appendChild(deleteBtn);

  row.appendChild(actions);

  row.addEventListener('dragstart', function (e) {
    e.dataTransfer.setData('text/bookmark-id', bm.id);
    e.dataTransfer.effectAllowed = 'move';
    row.classList.add('bm-dragging');
    document.querySelectorAll('.bm-detail-dropzone').forEach(z => z.classList.add('bm-drop-visible'));
    document.querySelectorAll('.bm-gallery-card').forEach(c => c.classList.add('bm-drag-hint'));
  });
  row.addEventListener('dragend', function () {
    row.classList.remove('bm-dragging');
    document.querySelectorAll('.bm-detail-dropzone').forEach(z => z.classList.remove('bm-drop-visible'));
    document.querySelectorAll('.bm-drop-target').forEach(z => z.classList.remove('bm-drop-target'));
    document.querySelectorAll('.bm-gallery-card').forEach(c => c.classList.remove('bm-drag-hint'));
    document.querySelectorAll('.bm-drop-above, .bm-drop-below').forEach(z => z.classList.remove('bm-drop-above', 'bm-drop-below'));
  });

  return row;
}

function editBookmark(bm) {
  // First look up the existing Tab0 shortcut for this bookmark
  chrome.runtime.sendMessage({ action: 'getShortcutForBookmark', bookmarkId: bm.id }, function (shortcutResponse) {
    let existingShortcutKey = (shortcutResponse && shortcutResponse.key) ? shortcutResponse.key : '';
    let existingTags = (shortcutResponse && shortcutResponse.data && shortcutResponse.data.tags) ? shortcutResponse.data.tags : generateTagsFromBookmark(bm.title, bm.url);

    chrome.runtime.sendMessage({ action: 'getBookmarkFolders' }, function (folders) {
      folders = folders || [];

      let folderSelectData = folders.map(function (f) {
        let indent = '';
        for (let i = 0; i < f.depth; i++) indent += '\u00A0\u00A0';
        return { value: f.id, label: indent + (f.title || '(Untitled)') };
      });

      let editBmTagsConf = { id: 'tags', tags: existingTags.slice() };
      showModal({
        title: 'Edit Bookmark',
        inputs: [
          { id: 'bmname', label: 'Bookmark Name (updates Chrome bookmark)', value: bm.title || '', placeholder: 'e.g. Book Fusion' },
          { id: 'shortcut', label: 'Tab0 Shortcut (lowercase, no spaces)', value: existingShortcutKey, placeholder: 'e.g. bookfusion or bf' },
          { id: 'url', label: 'URL', value: bm.url || '', placeholder: 'https://example.com' },
          { id: 'folder', label: 'Folder', type: 'select', selectOptions: folderSelectData, value: bm.parentId },
          { id: 'tags', label: 'Tags (up to 5, press Enter to add)', type: 'tags' }
        ],
        _tagsInputs: [editBmTagsConf],
        buttons: [
          { text: 'Cancel', className: 'dm-btn-cancel' },
          {
            text: 'Save', className: 'dm-btn-save', onClick: async function () {
              let newTitle = document.getElementById('dm-input-bmname').value.trim();
              let newUrl = document.getElementById('dm-input-url').value.trim();
              let folderSelect = document.getElementById('dm-input-folder');
              let newParentId = folderSelect.value || null;
              let newShortcutName = document.getElementById('dm-input-shortcut').value.trim().toLowerCase().replace(/\s+/g, '');
              let tags = editBmTagsConf.instance ? editBmTagsConf.instance.getTags() : [];

              if (!newTitle) { showToast('Name required.', 'error'); return; }
              if (!newUrl || !isSaveableUrl(newUrl)) { showToast('Valid URL required.', 'error'); return; }
              if (newShortcutName && newShortcutName.length > 15) { showToast('Shortcut name too long (max 15).', 'error'); return; }

              // 1. Update the Chrome bookmark
              let updateMsg = { action: 'updateBookmark', id: bm.id, title: newTitle, url: newUrl };
              if (newParentId && newParentId !== bm.parentId) {
                updateMsg.parentId = newParentId;
              }

              chrome.runtime.sendMessage(updateMsg, async function () {
                // 2. Handle Tab0 shortcut rename/create
                if (newShortcutName) {
                  if (existingShortcutKey && existingShortcutKey !== newShortcutName) {
                    // Rename shortcut key
                    chrome.runtime.sendMessage({
                      action: 'updateShortcutKey',
                      oldKey: existingShortcutKey,
                      newKey: newShortcutName,
                      extraData: { url: newUrl, bookmarkId: bm.id, bookmarkTitle: newTitle, tags: tags }
                    }, function () {
                      showToast('Bookmark & shortcut updated!', 'success');
                    });
                  } else if (!existingShortcutKey) {
                    // Create new shortcut
                    try {
                      let all = await storageGet(null);
                      if (all[newShortcutName] && isShortcutKey(newShortcutName)) {
                        showToast(newShortcutName + ' already exists as a shortcut!', 'error');
                      } else {
                        await storageSet({ [newShortcutName]: { url: newUrl, count: 0, bookmarkId: bm.id, bookmarkTitle: newTitle, tags: tags, createdAt: Date.now() } });
                        showToast('Bookmark updated & shortcut created!', 'success');
                      }
                    } catch (err) {
                      showToast('Error: ' + err.message, 'error');
                    }
                  } else {
                    // Same key, just update data
                    try {
                      let all = await storageGet(null);
                      let existing = all[existingShortcutKey] || {};
                      existing.url = newUrl;
                      existing.bookmarkTitle = newTitle;
                      existing.tags = tags;
                      await storageSet({ [existingShortcutKey]: existing });
                      showToast('Bookmark updated!', 'success');
                    } catch (err) {
                      showToast('Error: ' + err.message, 'error');
                    }
                  }
                } else {
                  showToast('Bookmark updated!', 'success');
                }

                if (openPanels.length > 0) refreshOpenPanels();
                loadBookmarksView(true);
                loadShortcutsTable();
              });
            }
          }
        ]
      });
    });
  });
}

function deleteBookmark(bm) {
  showModal({
    title: 'Delete Bookmark',
    body: 'Permanently delete "' + (bm.title || bm.url) + '"?',
    buttons: [
      { text: 'Cancel', className: 'dm-btn-cancel' },
      {
        text: 'Delete', className: 'dm-btn-danger', onClick: function () {
          chrome.runtime.sendMessage({ action: 'removeBookmark', id: bm.id }, function () {
            showToast('Bookmark deleted.', 'success');
            if (openPanels.length > 0) refreshOpenPanels();
            loadBookmarksView(true);
          });
        }
      }
    ]
  });
}

// Close buttons are now on each panel (dynamic), handled in buildPanelElement

document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && openPanels.length > 0) closeFolderDetail();
});

// Bookmark search (works for both subtabs)
document.getElementById('bookmarkSearchInput').addEventListener('keyup', debounce(function () {
  let query = document.getElementById('bookmarkSearchInput').value.toLowerCase().trim();
  let grid = document.getElementById('bmGalleryGrid');
  let emptyEl = document.getElementById('bookmarksEmpty');

  // Also filter shortcuts table
  loadShortcutsTable();

  // Filter bookmark gallery
  closeFolderDetail();

  if (!query) {
    loadBookmarksView();
    return;
  }

  // Score and filter bookmarks: title > url
  let scored = allBookmarkNodes.map(function (bm) {
    let score = 0;
    let lt = (bm.title || '').toLowerCase();
    let lu = (bm.url || '').toLowerCase();
    if (lt === query) score += 400;
    else if (lt.startsWith(query)) score += 300;
    else if (lt.includes(query)) score += 200;
    else { let words = lt.split(/\s+/); if (words.some(w => w.startsWith(query))) score += 150; }
    if (lu.includes(query)) score += 50;
    return { bm: bm, score: score };
  }).filter(s => s.score > 0).sort((a, b) => b.score - a.score);

  let matches = scored.map(s => s.bm);

  grid.innerHTML = '';
  emptyEl.classList.add('hidden');

  if (matches.length === 0) {
    emptyEl.classList.remove('hidden');
    emptyEl.textContent = 'No bookmarks matching "' + query + '"';
    return;
  }

  let resultsCard = document.createElement('div');
  resultsCard.className = 'bm-search-results';
  let resultsHeader = document.createElement('div');
  resultsHeader.className = 'bm-search-header';
  resultsHeader.textContent = matches.length + ' result' + (matches.length !== 1 ? 's' : '');
  resultsCard.appendChild(resultsHeader);

  matches.slice(0, 50).forEach(function (bm) {
    let row = renderDetailBookmarkItem(bm, null);
    row.removeAttribute('draggable');
    row.querySelector('.bm-drag-handle').style.display = 'none';
    resultsCard.appendChild(row);
  });

  if (matches.length > 50) {
    let more = document.createElement('div');
    more.className = 'bm-more';
    more.textContent = '+ ' + (matches.length - 50) + ' more results. Refine your search.';
    resultsCard.appendChild(more);
  }

  grid.appendChild(resultsCard);
}, 300));

// Live sync: listen for bookmark changes from background
chrome.runtime.onMessage.addListener(function (request) {
  if (request.action === 'bookmarkChanged') {
    let bmView = document.getElementById('view-bookmarks');
    if (bmView.classList.contains('active')) {
      loadBookmarksView(true);
      if (openPanels.length > 0) refreshOpenPanels();
    }
    loadShortcutsTable();
  }
});

// ============================================================
// INIT
// ============================================================
function init() {
  loadBookmarksView();
  loadShortcutsTable();
  loadSettingsState();

  let params = new URLSearchParams(window.location.search);

  // If opened from context menu with a URL, switch to bookmarks + shortcuts tab
  if (params.get('newurl')) {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelector('[data-view="bookmarks"]').classList.add('active');
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.getElementById('view-bookmarks').classList.add('active');
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('[data-subtab="bm-shortcuts"]').classList.add('active');
    document.querySelectorAll('.subtab').forEach(s => s.classList.remove('active'));
    document.getElementById('subtab-bm-shortcuts').classList.add('active');
    loadShortcutsTable();
    setTimeout(() => document.getElementById('addShortcutBtn').click(), 300);
  }

  // If opened because a shortcut was not found in omnibox
  if (params.get('notfound')) {
    let missed = decodeURIComponent(params.get('notfound'));
    // Switch to shortcuts subtab
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelector('[data-view="bookmarks"]').classList.add('active');
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.getElementById('view-bookmarks').classList.add('active');
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('[data-subtab="bm-shortcuts"]').classList.add('active');
    document.querySelectorAll('.subtab').forEach(s => s.classList.remove('active'));
    document.getElementById('subtab-bm-shortcuts').classList.add('active');
    loadShortcutsTable();
    // Show a modal prompting the user to create the shortcut
    setTimeout(() => {
      showModal({
        title: 'Shortcut not found',
        body: 'No shortcut found for "' + missed + '". Would you like to create it?',
        buttons: [
          { text: 'Cancel', className: 'dm-btn-cancel' },
          {
            text: 'Create Shortcut', className: 'dm-btn-save', onClick: function () {
              // Open the add shortcut modal with the name pre-filled
              window.history.replaceState({}, '', 'manage.html');
              let notFoundTagsConf = { id: 'tags', tags: [] };
              // Load folders for the folder dropdown
              chrome.runtime.sendMessage({ action: 'getBookmarkFolders' }, function (folders) {
                if (chrome.runtime.lastError) folders = [];
                folders = folders || [];
                let folderSelectData = [{ value: '', label: 'No folder' }].concat(
                  folders.map(function (f) {
                    let indent = '';
                    for (let i = 0; i < f.depth; i++) indent += '\u00A0\u00A0';
                    return { value: f.id, label: indent + (f.title || '(Untitled)') };
                  })
                );
                showModal({
                  title: 'New Shortcut',
                  inputs: [
                    { id: 'name', label: 'Shortcut name (max 15 chars, no spaces)', value: missed, placeholder: 'e.g. yt' },
                    { id: 'url', label: 'URL', value: '', placeholder: 'https://example.com' },
                    { id: 'tags', label: 'Tags (optional, up to 5, press Enter to add)', type: 'tags' },
                    { id: 'folder', label: 'Folder', type: 'select', selectOptions: folderSelectData, value: '' }
                  ],
                  _tagsInputs: [notFoundTagsConf],
                  buttons: [
                    { text: 'Cancel', className: 'dm-btn-cancel' },
                    {
                      text: 'Save', className: 'dm-btn-save', onClick: async function () {
                        let name = document.getElementById('dm-input-name').value.trim().toLowerCase();
                        let url = document.getElementById('dm-input-url').value.trim();
                        let tags = notFoundTagsConf.instance ? notFoundTagsConf.instance.getTags() : [];
                        let folderSelect = document.getElementById('dm-input-folder');
                        let folderId = folderSelect ? folderSelect.value : '';
                        if (!name) { showToast('Name required.', 'error'); return; }
                        if (name.length > 15) { showToast('Name too long (max 15).', 'error'); return; }
                        if (/\s/.test(name)) { showToast('No spaces in name.', 'error'); return; }
                        if (!url || !isSaveableUrl(url)) { showToast('Valid URL required.', 'error'); return; }
                        try {
                          let all = await storageGet(null);
                          if (all[name] && isShortcutKey(name)) { showToast(name + ' already exists!', 'error'); return; }
                          // Default to Tab0 Shortcuts folder if none selected
                          if (!folderId) {
                            try {
                              folderId = await new Promise(resolve => {
                                chrome.runtime.sendMessage({ action: 'getTab0FolderId' }, resolve);
                              });
                            } catch (e) {}
                          }
                          // Create Chrome bookmark
                          let bookmarkId, bookmarkTitle;
                          if (folderId) {
                            try {
                              let bm = await new Promise((resolve, reject) => {
                                chrome.bookmarks.create({ title: name, url: url, parentId: folderId }, (result) => {
                                  if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                                  else resolve(result);
                                });
                              });
                              bookmarkId = bm.id;
                              bookmarkTitle = name;
                            } catch (e) { /* bookmark creation failed, still save shortcut */ }
                          }
                          let shortcutData = { url: url, count: 0, tags: tags, createdAt: Date.now() };
                          if (bookmarkId) { shortcutData.bookmarkId = bookmarkId; shortcutData.bookmarkTitle = bookmarkTitle; }
                          await storageSet({ [name]: shortcutData });
                          showToast('Created ' + name, 'success');
                          loadShortcutsTable();
                        } catch (err) {
                          showToast('Error: ' + err.message, 'error');
                        }
                      }
                    }
                  ]
                });
              });
            }
          }
        ]
      });
    }, 400);
    window.history.replaceState({}, '', 'manage.html');
  }
}

// ============================================================
// FOLDER SHORTCUT BAR & EDIT MODAL
// ============================================================

/**
 * Populates the shortcut bar below a folder panel header.
 * Shows existing folder shortcut or auto-generates one.
 */
async function populateFolderShortcutBar(folderNode, panelIndex) {
  let bar = document.getElementById('folderShortcutBar-' + panelIndex);
  if (!bar) return;
  bar.innerHTML = '';

  try {
    let allData = await storageGet(null);
    let existingKey = null;

    // Find existing folder-type shortcut matching this folder's ID
    for (let key in allData) {
      if (key.startsWith('__')) continue;
      let d = allData[key];
      if (d && typeof d === 'object' && d.type === 'folder' && d.folderId === folderNode.id) {
        existingKey = key;
        break;
      }
    }

    if (existingKey) {
      // Show existing shortcut
      bar.innerHTML =
        '<span class="folder-shortcut-label">Shortcut:</span>' +
        '<span class="folder-shortcut-value">0+[tab] ' + existingKey + '</span>';
    } else {
      // Auto-generate a shortcut name from folder title (first 3-5 letters of first word, or combine if too short)
      let words = (folderNode.title || '').toLowerCase().replace(/[^a-z0-9\s]+/g, '').trim().split(/\s+/).filter(Boolean);
      let raw = words[0] || 'folder';
      if (raw.length < 3 && words[1]) raw = raw + words[1]; // combine short first word with second
      let base = raw.substring(0, 5);
      if (base.length < 2) base = 'folder';
      let candidate = base;
      let suffix = 1;
      while (allData[candidate]) {
        candidate = base + suffix;
        suffix++;
      }

      // Collect URLs from this folder via bookmarks API (folderNode may not have children populated)
      let urls = [];
      try {
        let subtree = await new Promise((resolve) => {
          chrome.bookmarks.getSubTree(folderNode.id, (result) => {
            if (chrome.runtime.lastError) { resolve([]); return; }
            resolve(result || []);
          });
        });
        function collectUrls(node) {
          if (node.url) urls.push(node.url);
          if (node.children) node.children.forEach(collectUrls);
        }
        if (subtree[0]) collectUrls(subtree[0]);
      } catch (e) { /* ignore */ }

      if (urls.length > 0) {
        // Auto-save the folder shortcut
        await storageSet({
          [candidate]: {
            type: 'folder',
            urls: urls,
            folderId: folderNode.id,
            folderTitle: folderNode.title || candidate,
            count: 0,
            tags: ['folder'],
            createdAt: Date.now()
          }
        });

        bar.innerHTML =
          '<span class="folder-shortcut-label">Shortcut:</span>' +
          '<span class="folder-shortcut-value">0+[tab] ' + candidate + '</span>' +
          '<span class="folder-shortcut-auto">(auto-created)</span>';
      } else {
        bar.innerHTML = '<span class="folder-shortcut-label folder-shortcut-empty">No bookmarks in folder — shortcut will be created when bookmarks are added.</span>';
      }
    }
  } catch (err) {
    console.error('Tab0: populateFolderShortcutBar error:', err);
    bar.innerHTML = '<span class="folder-shortcut-label folder-shortcut-empty">Could not load shortcut info.</span>';
  }
}

// Populate the shortcut badge in the header (compact inline display)
async function populateFolderShortcutBadge(folderNode, panelIndex) {
  let badge = document.getElementById('folderShortcutBadge-' + panelIndex);
  if (!badge) return;
  try {
    let allData = await storageGet(null);
    for (let key in allData) {
      if (key.startsWith('__')) continue;
      let d = allData[key];
      if (d && typeof d === 'object' && d.type === 'folder' && d.folderId === folderNode.id) {
        badge.textContent = key;
        badge.title = 'Shortcut: 0+Tab → ' + key;
        return;
      }
    }
    badge.textContent = '';
  } catch (e) {
    badge.textContent = '';
  }
}

// Confirm and delete a bookmark folder
function confirmDeleteFolder(folderNode, panelIndex) {
  let total = countBookmarks(folderNode);
  let msg = 'Delete folder "' + (folderNode.title || 'Untitled') + '"';
  if (total > 0) msg += ' and its ' + total + ' bookmark' + (total !== 1 ? 's' : '');
  msg += '? This cannot be undone.';

  showModal({
    title: 'Delete Folder',
    body: msg,
    buttons: [
      { text: 'Cancel', className: 'dm-btn-outline' },
      {
        text: 'Delete', className: 'dm-btn-danger', onClick: function () {
          chrome.bookmarks.removeTree(folderNode.id, function () {
            if (chrome.runtime.lastError) {
              showToast('Error: ' + chrome.runtime.lastError.message, 'error');
              return;
            }
            // Remove matching shortcut from storage
            storageGet(null).then(function (allData) {
              for (let key in allData) {
                if (key.startsWith('__')) continue;
                let d = allData[key];
                if (d && typeof d === 'object' && d.type === 'folder' && d.folderId === folderNode.id) {
                  chrome.storage.sync.remove(key);
                  break;
                }
              }
            });
            // Close this panel and refresh
            openPanels.splice(panelIndex, 1);
            renderAllPanels();
            loadBookmarksView();
            showToast('Folder "' + (folderNode.title || 'Untitled') + '" deleted.', 'success');
          });
        }
      }
    ]
  });
}

// Close more dropdown when clicking outside
document.addEventListener('click', function () {
  document.querySelectorAll('.bm-more-dropdown.visible').forEach(function (d) {
    d.classList.remove('visible');
  });
});

/**
 * Opens a modal to edit the folder name and its associated shortcut.
 */
async function openFolderEditModal(folderNode, panelIndex) {
  let allData = await storageGet(null);
  let existingKey = null;

  // Find existing folder-type shortcut for this folder
  for (let key in allData) {
    if (key.startsWith('__')) continue;
    let d = allData[key];
    if (d && typeof d === 'object') {
      // Match by folderId or by folder name
      if ((d.type === 'folder' && d.folderId === folderNode.id) ||
          (d.folder && d.folder === folderNode.title && !d.url)) {
        existingKey = key;
        break;
      }
    }
  }

  let currentShortcutName = existingKey || '';

  // Build parent folder select options
  let bmTree = await new Promise(function (resolve) {
    chrome.bookmarks.getTree(function (tree) { resolve(tree || []); });
  });
  let parentFolders = [];
  function walkParents(node, depth) {
    if (!node.url && node.children && node.title) {
      // Don't include the current folder itself as a parent option
      if (node.id !== folderNode.id) {
        let indent = '';
        for (let i = 0; i < depth; i++) indent += '\u00A0\u00A0';
        parentFolders.push({ value: node.id, label: indent + node.title });
      }
    }
    if (node.children) node.children.forEach(function (c) { walkParents(c, depth + 1); });
  }
  bmTree.forEach(function (n) { walkParents(n, 0); });
  let currentParentId = folderNode.parentId || '1';

  showModal({
    title: 'Edit Folder',
    body: '',
    inputs: [
      { id: 'folderName', label: 'FOLDER NAME', type: 'text', value: folderNode.title || '', placeholder: 'Folder name' },
      { id: 'folderShortcut', label: 'FOLDER TAB0 SHORTCUT', type: 'text', value: currentShortcutName, placeholder: 'e.g. work' },
      { id: 'folderParent', label: 'PARENT FOLDER', type: 'select', selectOptions: parentFolders, value: currentParentId }
    ],
    buttons: [
      { text: 'Cancel', className: 'dm-btn-secondary' },
      {
        text: 'Save',
        className: 'dm-btn-primary',
        onClick: async function () {
          let newName = (document.getElementById('dm-input-folderName').value || '').trim();
          let newShortcut = (document.getElementById('dm-input-folderShortcut').value || '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');
          let newParentId = (document.getElementById('dm-input-folderParent').value || '').trim();

          if (!newName) {
            showToast('Folder name cannot be empty.', 'error');
            return;
          }

          try {
            // 1. Rename folder in Chrome bookmarks if name changed
            if (newName !== folderNode.title) {
              await new Promise((resolve, reject) => {
                chrome.bookmarks.update(folderNode.id, { title: newName }, (result) => {
                  if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                  else resolve(result);
                });
              });
              folderNode.title = newName;
            }

            // 1b. Move folder to new parent if changed
            if (newParentId && newParentId !== currentParentId) {
              await new Promise((resolve, reject) => {
                chrome.bookmarks.move(folderNode.id, { parentId: newParentId }, (result) => {
                  if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                  else resolve(result);
                });
              });
              folderNode.parentId = newParentId;
            }

            // 2. Update folder shortcut in storage
            // Collect current URLs from folder
            let children = await new Promise((resolve) => {
              chrome.bookmarks.getSubTree(folderNode.id, (result) => {
                if (chrome.runtime.lastError) { resolve([]); return; }
                resolve(result || []);
              });
            });
            let urls = [];
            function collectUrls(node) {
              if (node.url) urls.push(node.url);
              if (node.children) node.children.forEach(collectUrls);
            }
            if (children[0]) collectUrls(children[0]);

            // Remove old shortcut key if it changed
            if (existingKey && newShortcut && existingKey !== newShortcut) {
              await storageRemove(existingKey);
            }
            // Remove old shortcut if user cleared the shortcut field
            if (existingKey && !newShortcut) {
              await storageRemove(existingKey);
            }

            // Save new/updated shortcut if name provided and folder has URLs
            if (newShortcut && urls.length > 0) {
              // Check for name conflict (not with itself)
              let conflictData = allData[newShortcut];
              if (conflictData && newShortcut !== existingKey) {
                showToast('Shortcut "' + newShortcut + '" already exists.', 'error');
                return;
              }

              await storageSet({
                [newShortcut]: {
                  type: 'folder',
                  urls: urls,
                  folderId: folderNode.id,
                  folderTitle: newName,
                  count: (existingKey && allData[existingKey]) ? (allData[existingKey].count || 0) : 0,
                  tags: ['folder'],
                  createdAt: (existingKey && allData[existingKey]) ? (allData[existingKey].createdAt || Date.now()) : Date.now()
                }
              });
            }

            showToast('Folder updated!', 'success');

            // Refresh UI
            refreshOpenPanels();
            loadBookmarksView(true);
            loadShortcutsTable();

            // Re-populate shortcut bar
            populateFolderShortcutBar(folderNode, panelIndex);

          } catch (err) {
            showToast('Error: ' + err.message, 'error');
          }
        }
      }
    ]
  });
}

init();

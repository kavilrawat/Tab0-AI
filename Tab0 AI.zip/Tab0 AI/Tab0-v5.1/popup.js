// ============================================================
// TAB0 - Popup Script (Redesigned with theme + bookmark fields)
// ============================================================

const INTERNAL_KEYS = ['__ssg_folders', '__ssg_settings'];
function isShortcutKey(key) { return !INTERNAL_KEYS.includes(key); }

// --- Storage helpers ---
function storageGet(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.get(keys, (r) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(r);
    });
  });
}

function storageSet(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.set(data, () => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

function storageRemove(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.remove(keys, () => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve();
    });
  });
}

// --- Toast ---
function showToast(message, type) {
  type = type || 'info';
  let toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = 'toast toast-' + type;
  setTimeout(() => toast.classList.add('toast-visible'), 10);
  setTimeout(() => {
    toast.classList.remove('toast-visible');
    setTimeout(() => toast.className = 'toast hidden', 300);
  }, 2500);
}

// --- Modal ---
function showModal(options) {
  let overlay = document.getElementById('modalOverlay');
  document.getElementById('modalTitle').textContent = options.title || '';
  document.getElementById('modalBody').textContent = options.body || '';
  let inputsEl = document.getElementById('modalInputs');
  let actionsEl = document.getElementById('modalActions');
  inputsEl.innerHTML = '';
  actionsEl.innerHTML = '';

  if (options.inputs) {
    options.inputs.forEach(function (inp) {
      let label = document.createElement('label');
      label.textContent = inp.label;

      let input;
      if (inp.type === 'select') {
        input = document.createElement('select');
        input.id = 'modal-input-' + inp.id;
        input.className = 'modal-input folder-select';
        let opts = inp.selectOptions || [];
        opts.forEach(function (opt) {
          let o = document.createElement('option');
          o.value = opt.value;
          o.textContent = opt.label;
          if (String(opt.value) === String(inp.value)) o.selected = true;
          input.appendChild(o);
        });
      } else if (inp.type === 'tags') {
        input = document.createElement('div');
        input.id = 'modal-input-' + inp.id;
        input.className = 'tags-input-container';
      } else {
        input = document.createElement('input');
        input.type = inp.type || 'text';
        input.id = 'modal-input-' + inp.id;
        input.value = inp.value || '';
        input.placeholder = inp.placeholder || '';
        input.className = 'modal-input';
      }

      inputsEl.appendChild(label);
      inputsEl.appendChild(input);
    });
  }

  // Render tags inputs after DOM is ready
  if (options._tagsInputs) {
    options._tagsInputs.forEach(function (tagConf) {
      tagConf.instance = createPopupTagsInput('modal-input-' + tagConf.id, tagConf.tags.slice());
    });
  }

  if (options.buttons) {
    options.buttons.forEach(function (btn) {
      let button = document.createElement('button');
      button.textContent = btn.text;
      button.className = 'modal-btn ' + (btn.className || '');
      button.addEventListener('click', function () {
        hideModal();
        if (btn.onClick) btn.onClick();
      });
      actionsEl.appendChild(button);
    });
  }

  overlay.classList.remove('hidden');
  let firstInput = inputsEl.querySelector('input, select');
  if (firstInput) setTimeout(() => firstInput.focus(), 50);
}

function hideModal() {
  document.getElementById('modalOverlay').classList.add('hidden');
}

document.getElementById('modalOverlay').addEventListener('click', function (e) {
  if (e.target === this) hideModal();
});

// --- URL validation ---
function isValidUrl(str) {
  try {
    let url = new URL(str);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (e) {
    return false;
  }
}

// Broader check: anything that can be bookmarked (http, https, chrome-extension, file, ftp, etc.)
function isSaveableUrl(str) {
  if (!str) return false;
  // Block truly unsaveable pages
  let blocked = ['about:blank', 'about:newtab', 'chrome://newtab/', 'chrome://new-tab-page/'];
  if (blocked.includes(str)) return false;
  try {
    new URL(str);
    return true;
  } catch (e) {
    return false;
  }
}

// --- Debounce ---
function debounce(fn, delay) {
  let timer;
  return function () { clearTimeout(timer); timer = setTimeout(fn, delay); };
}

// --- Get favicon URL ---
function getFaviconUrl(url) {
  try {
    let domain = new URL(url).hostname;
    return 'https://www.google.com/s2/favicons?domain=' + domain + '&sz=32';
  } catch (e) {
    return '';
  }
}

// --- Tag generation (same logic as manage.js) ---
function generateTagsFromBookmark(title, url) {
  let tags = [];
  try {
    let hostname = new URL(url).hostname.replace('www.', '');
    let domainTag = hostname.split('.')[0];
    if (domainTag && domainTag.length > 1) tags.push(domainTag);
  } catch (e) {}
  let titleWords = (title || '').toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2 && !['the', 'and', 'for', 'com', 'www', 'http', 'https', 'org', 'net'].includes(w));
  titleWords.forEach(function (w) {
    if (tags.length < 3 && !tags.includes(w)) tags.push(w);
  });
  let urlStr = (url || '').toLowerCase();
  if (tags.length < 3) {
    if (urlStr.includes('github') || urlStr.includes('gitlab')) { if (!tags.includes('dev')) tags.push('dev'); }
    else if (urlStr.includes('docs.') || urlStr.includes('/docs') || urlStr.includes('wiki')) { if (!tags.includes('docs')) tags.push('docs'); }
    else if (urlStr.includes('mail.') || urlStr.includes('gmail') || urlStr.includes('outlook')) { if (!tags.includes('email')) tags.push('email'); }
    else if (urlStr.includes('drive.') || urlStr.includes('dropbox') || urlStr.includes('cloud')) { if (!tags.includes('cloud')) tags.push('cloud'); }
    else if (urlStr.includes('youtube') || urlStr.includes('vimeo') || urlStr.includes('video')) { if (!tags.includes('video')) tags.push('video'); }
    else if (urlStr.includes('slack') || urlStr.includes('discord') || urlStr.includes('teams')) { if (!tags.includes('chat')) tags.push('chat'); }
    else if (urlStr.includes('figma') || urlStr.includes('canva') || urlStr.includes('design')) { if (!tags.includes('design')) tags.push('design'); }
    else if (urlStr.includes('support') || urlStr.includes('desk') || urlStr.includes('helpdesk')) { if (!tags.includes('support')) tags.push('support'); }
  }
  return tags.slice(0, 3);
}

// --- Tags input widget (same as dashboard) ---
let popupTagsWidget = null;
let popupTags = [];

function createPopupTagsInput(containerId, existingTags) {
  let wrapper = document.getElementById(containerId);
  if (!wrapper) return null;
  existingTags = existingTags || [];

  function render() {
    wrapper.innerHTML = '';
    wrapper.className = 'tags-input-wrapper';

    let tagsRow = document.createElement('div');
    tagsRow.className = 'tags-input-tags';

    existingTags.forEach(function (tag, idx) {
      let pill = document.createElement('span');
      pill.className = 'tag-pill tag-pill-editable';
      pill.textContent = tag;

      let removeBtn = document.createElement('button');
      removeBtn.className = 'tag-pill-remove';
      removeBtn.innerHTML = '&times;';
      removeBtn.title = 'Remove tag';
      removeBtn.addEventListener('click', function (e) {
        e.preventDefault();
        existingTags.splice(idx, 1);
        render();
      });
      pill.appendChild(removeBtn);
      tagsRow.appendChild(pill);
    });

    wrapper.appendChild(tagsRow);

    if (existingTags.length < 5) {
      let addInput = document.createElement('input');
      addInput.type = 'text';
      addInput.className = 'tags-input-field';
      addInput.placeholder = existingTags.length === 0 ? 'Add a tag...' : 'Add another...';
      addInput.maxLength = 20;
      addInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ',') {
          e.preventDefault();
          let val = this.value.trim().toLowerCase().replace(/[^a-z0-9-]/g, '');
          if (val && !existingTags.includes(val) && existingTags.length < 5) {
            existingTags.push(val);
            render();
          } else {
            this.value = '';
          }
        }
      });
      wrapper.appendChild(addInput);
    }
  }

  render();
  return { getTags: function () { return existingTags.slice(); }, setTags: function (tags) { existingTags.length = 0; tags.forEach(t => existingTags.push(t)); render(); } };
}

// ============================================================
// THEME SYNC (from dashboard localStorage via storage.sync)
// ============================================================
function applyTheme() {
  // Read theme from localStorage (shared with manage page)
  let theme = localStorage.getItem('tab0_theme') || 'dark';
  document.body.className = theme === 'dark' ? 'theme-dark' : '';
}
applyTheme();

// ============================================================
// VIEW MODE TOGGLE (grid / list)
// ============================================================
let currentViewMode = localStorage.getItem('tab0_view_mode') || 'grid';

function applyViewMode() {
  let list = document.getElementById('shortcutList');
  let toggleBtn = document.getElementById('viewToggle');
  let icon = document.getElementById('viewToggleIcon');

  if (currentViewMode === 'list') {
    list.className = 'shortcuts-list';
    toggleBtn.title = 'Switch to grid view';
    // Grid icon (switch TO grid)
    icon.innerHTML = '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>';
  } else {
    list.className = 'shortcuts-grid';
    toggleBtn.title = 'Switch to list view';
    // List icon (switch TO list)
    icon.innerHTML = '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>';
  }
}

// ============================================================
// SHOW CURRENT TAB INFO
// ============================================================
let currentTabUrl = '';
let currentTabTitle = '';

// Generate a smart short shortcut name (max 5 chars, unique)
function generateSmartShortName(title, url, existingKeys) {
  let candidates = [];

  // 1. Try domain-based short name (e.g. "desk" from desk.zoho.com, "reddit" → "redit")
  try {
    let hostname = new URL(url).hostname.replace('www.', '');
    let domain = hostname.split('.')[0];
    if (domain && domain.length > 1) {
      if (domain.length <= 5) candidates.push(domain);
      else candidates.push(domain.substring(0, 5));
      // Also try first 4, 3
      if (domain.length > 4) candidates.push(domain.substring(0, 4));
      if (domain.length > 3) candidates.push(domain.substring(0, 3));
    }
  } catch (e) {}

  // 2. Try meaningful words from the title
  let words = (title || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/)
    .filter(w => w.length > 2 && !['the', 'and', 'for', 'com', 'www', 'http', 'https', 'org', 'net', 'pvt', 'ltd'].includes(w));
  words.forEach(function (w) {
    if (w.length <= 5) candidates.push(w);
    else candidates.push(w.substring(0, 5));
  });

  // 3. Try combining first letters of title words
  if (words.length >= 2) {
    let initials = words.map(w => w[0]).join('').substring(0, 5);
    if (initials.length >= 2) candidates.push(initials);
  }

  // Find first candidate not in existingKeys
  for (let i = 0; i < candidates.length; i++) {
    let name = candidates[i].replace(/[^a-z0-9]/g, '');
    if (name && name.length >= 2 && name.length <= 5 && !existingKeys.includes(name)) {
      return name;
    }
  }

  // Fallback: first 4 chars of domain + number
  let base = candidates[0] || 'link';
  base = base.substring(0, 4);
  for (let n = 1; n <= 99; n++) {
    let attempt = base + n;
    if (!existingKeys.includes(attempt)) return attempt;
  }
  return '';
}

async function showCurrentTabInfo() {
  try {
    let tabs = await new Promise(resolve => chrome.tabs.query({ active: true, currentWindow: true }, resolve));
    let tab = tabs[0];
    currentTabUrl = tab ? tab.url : '';
    currentTabTitle = tab ? tab.title : '';
    // Detect New Tab / blank pages
    let newTabUrls = ['about:blank', 'about:newtab', 'chrome://newtab/', 'chrome://new-tab-page/', 'edge://newtab/'];
    let isNewTab = !currentTabUrl || newTabUrls.includes(currentTabUrl) || currentTabUrl.startsWith('chrome://newtab');

    document.getElementById('urlDisplay').value = isNewTab ? '' : (currentTabUrl || '');
    document.getElementById('bookmarkName').value = isNewTab ? '' : (currentTabTitle || '');

    let shortcutInput = document.getElementById('shortcutName');

    if (isNewTab) {
      // Don't suggest a shortcut name or tags for New Tab pages
      shortcutInput.value = '';
      shortcutInput.placeholder = 'e.g. desk';
      popupTagsWidget = createPopupTagsInput('popupTagsContainer', []);
      document.getElementById('savedBanner').classList.add('hidden');
      loadFolderDropdown(); // Default to Tab0 Shortcuts
      return;
    }

    // Check if this URL already has a shortcut saved
    let allItems = await storageGet(null);
    let existingKeys = Object.keys(allItems).filter(isShortcutKey);
    let existingShortcutName = '';

    for (let i = 0; i < existingKeys.length; i++) {
      let data = allItems[existingKeys[i]];
      let savedUrl = typeof data === 'object' ? data.url : data;
      if (savedUrl === currentTabUrl) {
        existingShortcutName = existingKeys[i];
        break;
      }
    }

    let savedBanner = document.getElementById('savedBanner');
    let savedBannerText = document.getElementById('savedBannerText');
    let savedBannerFolder = document.getElementById('savedBannerFolder');

    if (existingShortcutName) {
      // URL already saved — prefill with existing shortcut name
      shortcutInput.value = existingShortcutName;
      shortcutInput.placeholder = 'e.g. ' + existingShortcutName;

      // Show "already saved" banner
      savedBannerText.textContent = 'Saved as "' + existingShortcutName + '"';
      savedBanner.classList.remove('hidden');

      // Look up the bookmark folder name and pre-select it in dropdown
      let existingData = allItems[existingShortcutName];
      let preselectFolderId = '';
      if (typeof existingData === 'object' && existingData.bookmarkId) {
        try {
          let bmNode = await new Promise(resolve => {
            chrome.bookmarks.get(existingData.bookmarkId, (results) => {
              if (chrome.runtime.lastError) { resolve(null); return; }
              resolve(results ? results[0] : null);
            });
          });
          if (bmNode && bmNode.parentId) {
            preselectFolderId = bmNode.parentId;
            let parentNode = await new Promise(resolve => {
              chrome.bookmarks.get(bmNode.parentId, (results) => {
                if (chrome.runtime.lastError) { resolve(null); return; }
                resolve(results ? results[0] : null);
              });
            });
            if (parentNode && parentNode.title) {
              savedBannerFolder.textContent = parentNode.title;
            } else {
              savedBannerFolder.textContent = '';
            }
          } else {
            savedBannerFolder.textContent = '';
          }
        } catch (e) {
          savedBannerFolder.textContent = '';
        }
      } else {
        savedBannerFolder.textContent = '';
      }

      // Load folder dropdown with the existing bookmark's folder pre-selected
      loadFolderDropdown(preselectFolderId);

      // Prefill tags from existing data
      let existingTags = (typeof existingData === 'object' && Array.isArray(existingData.tags)) ? existingData.tags : generateTagsFromBookmark(currentTabTitle, currentTabUrl);
      popupTagsWidget = createPopupTagsInput('popupTagsContainer', existingTags);
    } else {
      // Not saved — hide banner
      savedBanner.classList.add('hidden');
      savedBannerFolder.textContent = '';

      // Load folder dropdown with Tab0 Shortcuts as default
      loadFolderDropdown();

      // Generate smart short name suggestion
      let smartName = generateSmartShortName(currentTabTitle, currentTabUrl, existingKeys);
      shortcutInput.value = smartName;
      shortcutInput.placeholder = smartName ? 'e.g. ' + smartName : 'e.g. desk';

      // Auto-generate tags and render widget
      let tags = generateTagsFromBookmark(currentTabTitle, currentTabUrl);
      popupTagsWidget = createPopupTagsInput('popupTagsContainer', tags);
    }
  } catch (e) {
    // Silently fail
  }
}

// ============================================================
// LOAD BOOKMARK FOLDERS (for folder dropdown)
// ============================================================
async function loadFolderDropdown(preselectFolderId) {
  try {
    let timeout = setTimeout(() => {
      console.warn('Tab0: loadFolderDropdown timed out');
    }, 3000);
    chrome.runtime.sendMessage({ action: 'getBookmarkFolders' }, function (folders) {
      clearTimeout(timeout);
      if (chrome.runtime.lastError) {
        console.warn('Tab0: getBookmarkFolders failed:', chrome.runtime.lastError.message);
        return;
      }
      let select = document.getElementById('folderSelect');
      select.innerHTML = '<option value="">Select folder...</option>';
      if (!folders || !Array.isArray(folders)) return;

      let tab0FolderId = '';
      folders.forEach(function (f) {
        let opt = document.createElement('option');
        opt.value = f.id;
        let indent = '';
        for (let i = 0; i < f.depth; i++) indent += '\u00A0\u00A0';
        opt.textContent = indent + (f.title || '(Untitled)');
        select.appendChild(opt);

        // Track the Tab0 Shortcuts folder ID
        if (f.title === 'Tab0 Shortcuts') {
          tab0FolderId = f.id;
        }
      });

      // Auto-select: use preselectFolderId if given, otherwise default to Tab0 Shortcuts
      let targetId = preselectFolderId || tab0FolderId;
      if (targetId) {
        select.value = targetId;
      }
    });
  } catch (e) {
    console.warn('Tab0: loadFolderDropdown error:', e.message);
  }
}

// ============================================================
// SAVE (creates both a Chrome bookmark + Tab0 shortcut)
// ============================================================
async function saveShortcut() {

  let bookmarkTitle = document.getElementById('bookmarkName').value.trim();
  let shortcutName = document.getElementById('shortcutName').value.trim().toLowerCase().replace(/\s+/g, '');
  let folderId = document.getElementById('folderSelect').value || undefined;


  if (!shortcutName && !bookmarkTitle) { showToast('Enter a name.', 'error'); return; }
  if (shortcutName && shortcutName.length > 15) { showToast('Shortcut name must be 15 chars or less.', 'error'); return; }
  if (shortcutName && /\s/.test(shortcutName)) { showToast('No spaces in shortcut name.', 'error'); return; }

  try {
    let url = document.getElementById('urlDisplay').value.trim();

    if (!url) { showToast('Enter a URL.', 'error'); return; }
    if (!isSaveableUrl(url)) {
      showToast('Enter a valid URL.', 'error'); return;
    }

    // Get tags from widget
    let tags = popupTagsWidget ? popupTagsWidget.getTags() : [];

    let items = await storageGet(null);

    // Create shortcut if name provided
    if (shortcutName) {
      if (items[shortcutName] && isShortcutKey(shortcutName)) {
        showToast(shortcutName + ' already exists!', 'error'); return;
      }
    }

    // If no folder selected, default to "Tab0 Shortcuts" folder
    if (!folderId) {
      try {
        folderId = await new Promise((resolve, reject) => {
          let timeout = setTimeout(() => resolve(undefined), 3000); // Prevent hanging if service worker is asleep
          chrome.runtime.sendMessage({ action: 'getTab0FolderId' }, (response) => {
            clearTimeout(timeout);
            if (chrome.runtime.lastError) {
              console.warn('Tab0: getTab0FolderId failed:', chrome.runtime.lastError.message);
              resolve(undefined);
            } else {
              resolve(response);
            }
          });
        });
      } catch (e) { /* fallback: no folder */ }
    }

    // Validate folderId is actually a folder before using it
    if (folderId) {
      try {
        let folderCheck = await new Promise((resolve) => {
          chrome.bookmarks.get(folderId, (results) => {
            if (chrome.runtime.lastError || !results || results.length === 0) {
              resolve(null);
            } else {
              resolve(results[0]);
            }
          });
        });
        // If the ID doesn't exist or points to a bookmark (has a URL), discard it
        if (!folderCheck || folderCheck.url) {
          console.warn('Tab0: folderId', folderId, 'is not a valid folder, ignoring');
          folderId = undefined;
        }
      } catch (e) {
        console.warn('Tab0: folderId validation failed:', e.message);
        folderId = undefined;
      }
    }

    // Create Chrome bookmark if title provided
    let bookmarkId = undefined;
    if (bookmarkTitle) {
      try {
        let createOpts = { title: bookmarkTitle, url: url };
        if (folderId) createOpts.parentId = folderId;
        let bm = await new Promise((resolve, reject) => {
          let timeout = setTimeout(() => {
            console.warn('Tab0: Bookmark creation timed out');
            resolve(null);
          }, 5000);
          chrome.bookmarks.create(createOpts, (result) => {
            clearTimeout(timeout);
            if (chrome.runtime.lastError) {
              console.warn('Tab0: Bookmark creation failed:', chrome.runtime.lastError.message);
              resolve(null); // Don't reject — still save the shortcut
            } else {
              resolve(result);
            }
          });
        });
        if (bm) bookmarkId = bm.id;
      } catch (e) {
        console.warn('Tab0: Bookmark creation error:', e.message);
        // Bookmark creation might fail — still save the shortcut
      }
    }

    // Save shortcut
    if (shortcutName) {
      let shortcutData = { url: url, count: 0, tags: tags, createdAt: Date.now() };
      if (bookmarkId) {
        shortcutData.bookmarkId = bookmarkId;
        shortcutData.bookmarkTitle = bookmarkTitle;
      }

      await storageSet({ [shortcutName]: shortcutData });

      showToast('Saved ' + shortcutName, 'success');
    } else if (bookmarkTitle) {
      showToast('Bookmark created!', 'success');
    }

    document.getElementById('shortcutName').value = '';
    document.getElementById('bookmarkName').value = '';
    // Reset tags widget
    if (popupTagsWidget) popupTagsWidget.setTags([]);
    loadShortcuts();
  } catch (err) {
    console.error('Tab0: saveShortcut error:', err);
    showToast('Error: ' + err.message, 'error');
  }
}

// ============================================================
// LOAD SHORTCUTS (with favicons)
// ============================================================
// Search scoring: higher score = better match
// Priority: Shortcut Name (4) > Bookmark Name (3) > Tags (2) > URL (1)
function getSearchScore(key, data, searchValue) {
  if (!searchValue) return 100; // No search = show all
  let isFolder = typeof data === 'object' && data.type === 'folder';
  let url = isFolder ? '' : ((typeof data === 'object') ? (data.url || '') : (data || ''));
  let bookmarkTitle = (typeof data === 'object') ? (data.bookmarkTitle || data.folderTitle || '') : '';
  let tags = (typeof data === 'object' && Array.isArray(data.tags)) ? data.tags : [];
  let score = 0;

  let lowerKey = key.toLowerCase();
  let lowerTitle = bookmarkTitle.toLowerCase();
  let lowerUrl = url.toLowerCase();

  // Shortcut name matches (highest priority)
  if (lowerKey === searchValue) score += 400; // Exact match
  else if (lowerKey.startsWith(searchValue)) score += 300; // Starts with
  else if (lowerKey.includes(searchValue)) score += 200; // Contains

  // Bookmark name matches
  if (lowerTitle === searchValue) score += 150;
  else if (lowerTitle.startsWith(searchValue)) score += 120;
  else if (lowerTitle.includes(searchValue)) score += 100;
  else {
    // Check individual words in bookmark title
    let words = lowerTitle.split(/\s+/);
    if (words.some(w => w.startsWith(searchValue))) score += 90;
  }

  // Tag matches
  for (let t of tags) {
    if (t === searchValue) { score += 80; break; }
    if (t.startsWith(searchValue)) { score += 60; break; }
    if (t.includes(searchValue)) { score += 40; break; }
  }

  // URL matches
  if (lowerUrl.includes(searchValue)) score += 20;

  return score;
}

// Helper: open all URLs in a folder shortcut
function openFolderShortcutUrls(urls) {
  if (!urls || urls.length === 0) return;
  // Open first URL in current tab, rest in new tabs
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (tabs[0]) {
      chrome.tabs.update(tabs[0].id, { url: urls[0] });
      for (let i = 1; i < urls.length; i++) {
        chrome.tabs.create({ url: urls[i] });
      }
      window.close();
    }
  });
}

// Helper: get truncated URL for list view display
function getDisplayUrl(url) {
  try {
    let u = new URL(url);
    let display = u.hostname.replace('www.', '');
    if (u.pathname && u.pathname !== '/') display += u.pathname;
    return display.length > 40 ? display.substring(0, 40) + '...' : display;
  } catch (e) {
    return url;
  }
}

async function loadShortcuts() {
  let searchValue = document.getElementById('searchShortcuts').value.toLowerCase().trim();

  try {
    let items = await storageGet(null);
    let list = document.getElementById('shortcutList');
    list.innerHTML = '';

    // Apply the current view mode class
    list.className = currentViewMode === 'list' ? 'shortcuts-list' : 'shortcuts-grid';

    let keys = Object.keys(items).filter(isShortcutKey);

    // Score and filter
    let scored = keys.map(function (key) {
      let data = items[key];
      let score = getSearchScore(key, data, searchValue);
      return { key: key, data: data, score: score };
    }).filter(s => s.score > 0);

    // Sort: if searching, sort by score then by count; otherwise sort by count
    if (searchValue) {
      scored.sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        let aCount = typeof a.data === 'object' ? (a.data.count || 0) : 0;
        let bCount = typeof b.data === 'object' ? (b.data.count || 0) : 0;
        return bCount - aCount;
      });
    } else {
      scored.sort((a, b) => {
        let aCount = typeof a.data === 'object' ? (a.data.count || 0) : 0;
        let bCount = typeof b.data === 'object' ? (b.data.count || 0) : 0;
        return bCount - aCount;
      });
    }

    let shown = 0;
    for (let i = 0; i < scored.length; i++) {
      let key = scored[i].key;
      let data = scored[i].data;
      let isFolder = typeof data === 'object' && data.type === 'folder';
      let url = isFolder ? '' : ((typeof data === 'object') ? data.url : data);
      let urls = isFolder ? (data.urls || []) : [];
      let count = (typeof data === 'object') ? (data.count || 0) : 0;
      let tags = (typeof data === 'object' && Array.isArray(data.tags)) ? data.tags : [];

      shown++;
      let li = document.createElement('li');

      let inner = document.createElement('div');
      inner.className = 'shortcut-inner';
      inner.style.cursor = 'pointer';

      if (isFolder) {
        // Click folder shortcut → open all URLs
        inner.addEventListener('click', function () {
          // Update access count
          data.count = (data.count || 0) + 1;
          data.lastAccessed = Date.now();
          storageSet({ [key]: data });
          openFolderShortcutUrls(urls);
        });
      } else {
        // Click single shortcut → open in same tab
        inner.addEventListener('click', function () {
          chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            if (tabs[0]) {
              chrome.tabs.update(tabs[0].id, { url: url });
              window.close();
            }
          });
        });
      }

      // Favicon / folder icon
      if (isFolder) {
        let folderSvg = document.createElement('span');
        folderSvg.className = 'shortcut-favicon';
        folderSvg.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';
        folderSvg.style.display = 'flex';
        folderSvg.style.alignItems = 'center';
        folderSvg.style.justifyContent = 'center';
        inner.appendChild(folderSvg);
      } else {
        let faviconUrl = getFaviconUrl(url);
        if (faviconUrl) {
          let img = document.createElement('img');
          img.src = faviconUrl;
          img.className = 'shortcut-favicon';
          img.alt = '';
          img.onerror = function () { this.style.display = 'none'; };
          inner.appendChild(img);
        }
      }

      // Name
      let name = document.createElement('span');
      name.className = 'shortcut-name';
      name.textContent = key;
      inner.appendChild(name);

      // URL text (visible in list view only, hidden in grid via CSS)
      let urlText = document.createElement('span');
      urlText.className = 'shortcut-url-text';
      if (isFolder) {
        urlText.textContent = urls.length + ' tab' + (urls.length !== 1 ? 's' : '');
      } else {
        urlText.textContent = getDisplayUrl(url);
      }
      inner.appendChild(urlText);

      // Folder badge (visible in list view for folder shortcuts)
      if (isFolder) {
        let badge = document.createElement('span');
        badge.className = 'shortcut-folder-badge';
        badge.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>' + urls.length + ' tabs';
        inner.appendChild(badge);
      }

      li.appendChild(inner);

      // Dropdown actions
      let dropdown = document.createElement('div');
      dropdown.className = 'dropdown-menu';

      let del = document.createElement('button');
      del.className = 'delete-icon';
      del.title = 'Delete';
      del.addEventListener('click', (e) => { e.stopPropagation(); deleteShortcut(key, url || ('folder:' + key)); });
      dropdown.appendChild(del);

      let edit = document.createElement('button');
      edit.className = 'edit-icon';
      edit.title = 'Edit';
      edit.addEventListener('click', (e) => { e.stopPropagation(); editShortcut(key, url || ('folder:' + key)); });
      dropdown.appendChild(edit);

      if (isFolder) {
        let openAll = document.createElement('button');
        openAll.className = 'go-to-icon';
        openAll.title = 'Open all in new tabs';
        openAll.addEventListener('click', (e) => {
          e.stopPropagation();
          urls.forEach(u => chrome.tabs.create({ url: u }));
        });
        dropdown.appendChild(openAll);
      } else {
        let go = document.createElement('button');
        go.className = 'go-to-icon';
        go.title = 'Open in new tab';
        go.addEventListener('click', (e) => { e.stopPropagation(); chrome.tabs.create({ url: url }); });
        dropdown.appendChild(go);
      }

      li.appendChild(dropdown);
      list.appendChild(li);
    }

    if (shown === 0) {
      let empty = document.createElement('li');
      empty.className = 'empty-state';
      empty.textContent = keys.length === 0 ? 'No shortcuts yet. Create one above!' : 'No matches found.';
      list.appendChild(empty);
    }
  } catch (err) {
    showToast('Error loading: ' + err.message, 'error');
  }
}

// ============================================================
// DELETE & EDIT (modal-based)
// ============================================================
function deleteShortcut(name, url) {
  showModal({
    title: 'Delete ' + name + '?',
    body: 'This will permanently remove this shortcut.',
    buttons: [
      { text: 'Cancel', className: 'modal-btn-cancel' },
      {
        text: 'Delete', className: 'modal-btn-danger', onClick: async function () {
          try {
            await storageRemove(name);
            showToast('Deleted ' + name, 'success');
            loadShortcuts();
          } catch (err) { showToast('Error: ' + err.message, 'error'); }
        }
      }
    ]
  });
}

function editShortcut(key, url) {
  // Load existing shortcut data including tags
  storageGet(key).then(function (result) {
    let data = result[key] || {};
    let isFolder = typeof data === 'object' && data.type === 'folder';
    let existingTags = (typeof data === 'object' && Array.isArray(data.tags)) ? data.tags : generateTagsFromBookmark('', url);
    let editTagsConf = { id: 'tags', tags: existingTags.slice() };

    // For folder shortcuts, show a simpler edit modal
    if (isFolder) {
      showModal({
        title: 'Edit Folder Shortcut',
        inputs: [
          { id: 'name', label: 'Shortcut Name', value: key, placeholder: 'e.g. work' },
          { id: 'tags', label: 'Tags (up to 5, press Enter to add)', type: 'tags' }
        ],
        _tagsInputs: [editTagsConf],
        buttons: [
          { text: 'Cancel', className: 'modal-btn-cancel' },
          {
            text: 'Save', className: 'modal-btn-save', onClick: async function () {
              let newName = document.getElementById('modal-input-name').value.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
              let tags = editTagsConf.instance ? editTagsConf.instance.getTags() : [];
              if (!newName) { showToast('Name required.', 'error'); return; }
              if (newName.length > 15) { showToast('Too long.', 'error'); return; }
              try {
                let items = await storageGet(null);
                if (items[newName] && newName !== key) { showToast(newName + ' exists!', 'error'); return; }
                await storageRemove(key);
                await storageSet({ [newName]: { type: 'folder', urls: data.urls || [], folderId: data.folderId, folderTitle: data.folderTitle || newName, count: data.count || 0, tags: tags, createdAt: data.createdAt || Date.now() } });
                showToast('Updated ' + newName, 'success');
                loadShortcuts();
              } catch (err) { showToast('Error: ' + err.message, 'error'); }
            }
          }
        ]
      });
      return;
    }

    // Load folders for folder dropdown (regular shortcuts only)
    chrome.runtime.sendMessage({ action: 'getBookmarkFolders' }, function (folders) {
      if (chrome.runtime.lastError) folders = [];
      folders = folders || [];

      let folderSelectData = [{ value: '', label: 'No folder' }].concat(
        folders.map(function (f) {
          let indent = '';
          for (let i = 0; i < f.depth; i++) indent += '\u00A0\u00A0';
          return { value: f.id, label: indent + (f.title || '(Untitled)') };
        })
      );

      // Determine current folder from bookmark
      let currentFolderId = (data.bookmarkId) ? '' : '';

      showModal({
        title: 'Edit ' + key,
        inputs: [
          { id: 'name', label: 'Name', value: key, placeholder: 'e.g. yt' },
          { id: 'url', label: 'URL', value: url, placeholder: 'https://example.com' },
          { id: 'tags', label: 'Tags (up to 5, press Enter to add)', type: 'tags' },
          { id: 'folder', label: 'Folder', type: 'select', selectOptions: folderSelectData, value: currentFolderId }
        ],
        _tagsInputs: [editTagsConf],
        buttons: [
          { text: 'Cancel', className: 'modal-btn-cancel' },
          {
            text: 'Save', className: 'modal-btn-save', onClick: async function () {
              let newName = document.getElementById('modal-input-name').value.trim().toLowerCase();
              let newUrl = document.getElementById('modal-input-url').value.trim();
              let tags = editTagsConf.instance ? editTagsConf.instance.getTags() : [];
              let folderSelect = document.getElementById('modal-input-folder');
              let folderId = folderSelect ? folderSelect.value : '';
              if (!newName) { showToast('Name required.', 'error'); return; }
              if (newName.length > 15) { showToast('Too long.', 'error'); return; }
              if (/\s/.test(newName)) { showToast('No spaces.', 'error'); return; }
              if (!newUrl) { showToast('URL required.', 'error'); return; }
              if (!isSaveableUrl(newUrl)) { showToast('Invalid URL.', 'error'); return; }
              try {
                let items = await storageGet(null);
                if (items[newName] && newName !== key) { showToast(newName + ' exists!', 'error'); return; }
                let oldData = items[key] || {};
                let preserved = typeof oldData === 'object' ? oldData : {};

                // If there's an associated bookmark, update it too
                if (preserved.bookmarkId) {
                  chrome.runtime.sendMessage({
                    action: 'updateBookmark', id: preserved.bookmarkId, title: preserved.bookmarkTitle || newName, url: newUrl,
                    parentId: folderId || undefined
                  });
                }

                await storageRemove(key);
                await storageSet({ [newName]: { url: newUrl, count: preserved.count || 0, tags: tags, bookmarkId: preserved.bookmarkId, bookmarkTitle: preserved.bookmarkTitle, createdAt: preserved.createdAt || Date.now() } });
                showToast('Updated ' + newName, 'success');
                loadShortcuts();
              } catch (err) { showToast('Error: ' + err.message, 'error'); }
            }
          }
        ]
      });
    });
  });
}

// ============================================================
// SAVE FOLDER AS SHORTCUT
// Opens a modal listing all bookmark folders, user picks one and gives it a shortcut name
// ============================================================
async function saveFolderShortcut() {
  try {
    // Get all bookmark folders
    let folders = await new Promise((resolve) => {
      let timeout = setTimeout(() => resolve([]), 3000);
      chrome.runtime.sendMessage({ action: 'getBookmarkFolders' }, function (result) {
        clearTimeout(timeout);
        if (chrome.runtime.lastError) { resolve([]); return; }
        resolve(result || []);
      });
    });

    if (folders.length === 0) {
      showToast('No bookmark folders found.', 'error');
      return;
    }

    let folderSelectData = folders.map(function (f) {
      let indent = '';
      for (let i = 0; i < f.depth; i++) indent += '\u00A0\u00A0';
      return { value: f.id, label: indent + (f.title || '(Untitled)') };
    });

    showModal({
      title: 'Create Folder Shortcut',
      body: 'Pick a bookmark folder. All links inside it will open when you use this shortcut.',
      inputs: [
        { id: 'folder', label: 'Bookmark Folder', type: 'select', selectOptions: folderSelectData, value: '' },
        { id: 'name', label: 'Shortcut Name', placeholder: 'e.g. work', value: '' }
      ],
      buttons: [
        { text: 'Cancel', className: 'modal-btn-cancel' },
        {
          text: 'Save', className: 'modal-btn-save', onClick: async function () {
            let folderId = document.getElementById('modal-input-folder').value;
            let shortcutName = document.getElementById('modal-input-name').value.trim().toLowerCase().replace(/\s+/g, '');

            if (!folderId) { showToast('Select a folder.', 'error'); return; }
            if (!shortcutName) { showToast('Enter a shortcut name.', 'error'); return; }
            if (shortcutName.length > 15) { showToast('Name must be 15 chars or less.', 'error'); return; }

            try {
              // Check if name already taken
              let items = await storageGet(null);
              if (items[shortcutName] && isShortcutKey(shortcutName)) {
                showToast(shortcutName + ' already exists!', 'error');
                return;
              }

              // Get all URLs inside this folder
              let children = await new Promise((resolve) => {
                chrome.bookmarks.getSubTree(folderId, (result) => {
                  if (chrome.runtime.lastError) { resolve([]); return; }
                  resolve(result || []);
                });
              });

              let urls = [];
              let folderTitle = '';
              function collectUrls(node) {
                if (!folderTitle && !node.url && node.title) folderTitle = node.title;
                if (node.url) urls.push(node.url);
                if (node.children) node.children.forEach(collectUrls);
              }
              if (children[0]) collectUrls(children[0]);

              if (urls.length === 0) {
                showToast('This folder has no bookmarks.', 'error');
                return;
              }

              // Save as folder-type shortcut
              await storageSet({
                [shortcutName]: {
                  type: 'folder',
                  urls: urls,
                  folderId: folderId,
                  folderTitle: folderTitle || shortcutName,
                  count: 0,
                  tags: ['folder'],
                  createdAt: Date.now()
                }
              });

              showToast('Saved ' + shortcutName + ' (' + urls.length + ' tabs)', 'success');
              loadShortcuts();
            } catch (err) {
              showToast('Error: ' + err.message, 'error');
            }
          }
        }
      ]
    });
  } catch (e) {
    showToast('Error: ' + e.message, 'error');
  }
}

// ============================================================
// EVENT LISTENERS
// ============================================================
document.getElementById('saveButton').addEventListener('click', saveShortcut);
document.getElementById('cancelButton').addEventListener('click', () => window.close());
document.getElementById('shortcutName').addEventListener('keypress', (e) => { if (e.key === 'Enter') saveShortcut(); });
document.getElementById('searchShortcuts').addEventListener('keyup', debounce(loadShortcuts, 300));

// View toggle
document.getElementById('viewToggle').addEventListener('click', function () {
  currentViewMode = currentViewMode === 'grid' ? 'list' : 'grid';
  localStorage.setItem('tab0_view_mode', currentViewMode);
  applyViewMode();
  loadShortcuts();
});

document.getElementById('shareButton').addEventListener('click', function () {
  chrome.tabs.create({ url: 'https://chrome.google.com/webstore/detail/slash-space-go/ejcaloplfaackbkpdiidjgakbogilcdf/' });
});

document.getElementById('manageBtn').addEventListener('click', function () {
  chrome.tabs.create({ url: chrome.runtime.getURL('manage.html') });
});

chrome.runtime.onMessage.addListener(function (request) {
  if (request.action === 'createShortcut') {
    document.getElementById('shortcutName').value = request.url;
  }
});

// ============================================================
// INIT
// ============================================================
applyViewMode();
showCurrentTabInfo(); // This also calls loadFolderDropdown() with the right preselection
loadShortcuts();

// ============================================================
// TAB0 - Background Service Worker
// Handles: omnibox, context menu, bookmark sync, defaults
// ============================================================

// --- Internal storage keys (prefixed to avoid conflicts) ---
const INTERNAL_KEYS = ['__ssg_folders', '__ssg_settings'];

function isShortcutKey(key) {
  return !INTERNAL_KEYS.includes(key);
}

// --- Safely wrap chrome.storage calls ---
function storageGet(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.get(keys, (result) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(result);
      }
    });
  });
}

function storageSet(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.set(data, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

function storageRemove(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.remove(keys, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

// ============================================================
// SYNC LOCK - Prevents infinite loops between bookmark and
// storage listeners triggering each other
// ============================================================
let syncLock = false;

function withSyncLock(fn) {
  if (syncLock) return Promise.resolve();
  syncLock = true;
  return fn().finally(() => {
    setTimeout(() => { syncLock = false; }, 2000);
  });
}

// ============================================================
// ACCESS LOGGING — tracks daily open counts for stats
// ============================================================
async function logAccess(shortcutKey, url) {
  try {
    let result = await new Promise(resolve => chrome.storage.local.get('__tab0_daily_stats', resolve));
    let dailyStats = result['__tab0_daily_stats'] || {};
    let today = new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"

    if (!dailyStats[today]) dailyStats[today] = { opens: 0 };
    dailyStats[today].opens++;

    // Prune entries older than 90 days
    let cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - 90);
    let cutoffStr = cutoff.toISOString().slice(0, 10);
    Object.keys(dailyStats).forEach(d => { if (d < cutoffStr) delete dailyStats[d]; });

    await new Promise(resolve => chrome.storage.local.set({ '__tab0_daily_stats': dailyStats }, resolve));
  } catch (e) { /* ignore logging errors */ }
}

// ============================================================
// BOOKMARK BAR CLICK TRACKING
// Uses webNavigation to detect bookmark-triggered navigations
// ============================================================
chrome.webNavigation.onCommitted.addListener(async (details) => {
  // Only track main frame, bookmark-triggered navigations
  if (details.frameId !== 0) return;
  if (details.transitionType !== 'auto_bookmark') return;

  let url = details.url;
  if (!url || url === 'about:blank' || url.startsWith('chrome://')) return;

  try {
    let items = await storageGet(null);
    let keys = Object.keys(items).filter(isShortcutKey);

    // Find the shortcut that matches this URL
    for (let key of keys) {
      let data = items[key];
      let savedUrl = typeof data === 'object' ? data.url : data;
      if (savedUrl === url) {
        if (typeof data === 'object') {
          data.count = (data.count || 0) + 1;
          data.lastAccessed = Date.now();
          await storageSet({ [key]: data });
        } else {
          await storageSet({ [key]: { url: data, count: 1, lastAccessed: Date.now() } });
        }
        logAccess(key, url);
        break;
      }
    }
  } catch (e) { /* ignore */ }
});

// ============================================================
// KEYBOARD SHORTCUT: Ctrl+0 / Cmd+0 opens Dashboard
// ============================================================
chrome.commands.onCommand.addListener(function (command) {
  if (command === 'open-dashboard') {
    let dashUrl = chrome.runtime.getURL('manage.html');
    // Check if dashboard is already open, focus it instead of opening a new tab
    chrome.tabs.query({}, function (tabs) {
      if (chrome.runtime.lastError) {
        chrome.tabs.create({ url: dashUrl });
        return;
      }
      let existing = tabs.find(t => t.url && t.url.startsWith(dashUrl));
      if (existing) {
        chrome.tabs.update(existing.id, { active: true });
        chrome.windows.update(existing.windowId, { focused: true });
      } else {
        chrome.tabs.create({ url: dashUrl });
      }
    });
  }
});

// ============================================================
// CONTEXT MENU
// ============================================================
chrome.runtime.onInstalled.addListener(function (details) {
  chrome.contextMenus.create({
    id: 'createShortcut',
    title: 'Create Tab0 shortcut for this page',
    contexts: ['page']
  });

  chrome.storage.sync.get(null, function (items) {
    if (chrome.runtime.lastError) {
      console.error('Tab0: Storage error in onInstalled:', chrome.runtime.lastError.message);
      return;
    }
    let shortcuts = Object.keys(items).filter(isShortcutKey);
    if (shortcuts.length === 0) {
      let defaultShortcuts = {
        'yt': { url: 'https://www.youtube.com/', count: 0, folder: '' }
      };
      chrome.storage.sync.set(defaultShortcuts);
    }

    if (!items['__ssg_folders']) {
      chrome.storage.sync.set({ '__ssg_folders': ['Work', 'Social', 'Dev Tools', 'Other'] });
    }

    if (!items['__ssg_settings']) {
      chrome.storage.sync.set({ '__ssg_settings': { bookmarkSync: true } });
    }

    // Run migration after a short delay to let storage settle
    setTimeout(async () => {
      try {
        let all = await storageGet(null);

        // STEP 1: Migrate existing standalone shortcuts into "Tab0 Shortcuts" bookmark folder
        // These are shortcuts from Slash Space Go (or created without a folder) that have no bookmarkId
        let standaloneKeys = Object.keys(all).filter(isShortcutKey).filter(k => {
          let data = all[k];
          return typeof data === 'object' && !data.bookmarkId && data.url;
        });

        if (standaloneKeys.length > 0) {
          let tab0Folder = await getOrCreateBookmarkFolder();
          if (tab0Folder && tab0Folder.id) {
            for (let key of standaloneKeys) {
              let data = all[key];
              try {
                let bm = await new Promise((resolve, reject) => {
                  chrome.bookmarks.create({
                    parentId: tab0Folder.id,
                    title: data.bookmarkTitle || key,
                    url: data.url
                  }, (result) => {
                    if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                    else resolve(result);
                  });
                });
                // Link the bookmark to the shortcut
                data.bookmarkId = bm.id;
                if (!data.bookmarkTitle) data.bookmarkTitle = key;
                if (!data.tags) data.tags = [];
                if (!data.createdAt) data.createdAt = Date.now();
                await storageSet({ [key]: data });
              } catch (e) {
                console.warn('Tab0: Migration step 1 - bookmark creation failed for', key, ':', e.message);
              }
            }
          } else {
            console.warn('Tab0: Migration step 1 skipped - could not get/create bookmark folder');
          }
        }

        // STEP 2: Also handle old string-format shortcuts (url as plain string, not object)
        let oldFormatKeys = Object.keys(all).filter(isShortcutKey).filter(k => {
          return typeof all[k] === 'string';
        });

        if (oldFormatKeys.length > 0) {
          let tab0Folder = await getOrCreateBookmarkFolder();
          if (tab0Folder && tab0Folder.id) {
            for (let key of oldFormatKeys) {
              let url = all[key];
              try {
                let bm = await new Promise((resolve, reject) => {
                  chrome.bookmarks.create({
                    parentId: tab0Folder.id,
                    title: key,
                    url: url
                  }, (result) => {
                    if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                    else resolve(result);
                  });
                });
                // Upgrade to object format with bookmark link
                await storageSet({ [key]: {
                  url: url, count: 0, bookmarkId: bm.id, bookmarkTitle: key,
                  tags: [], createdAt: Date.now()
                }});
              } catch (e) {
                console.warn('Tab0: Migration step 2 - bookmark creation failed for', key, ':', e.message);
              }
            }
          } else {
            console.warn('Tab0: Migration step 2 skipped - could not get/create bookmark folder');
          }
        }

        // STEP 3: Remove old bookmark-linked shortcuts and re-import all bookmarks cleanly
        let refreshed = await storageGet(null);
        let toRemove = [];
        Object.keys(refreshed).filter(isShortcutKey).forEach(k => {
          let data = refreshed[k];
          if (typeof data === 'object' && data.bookmarkId) {
            toRemove.push(k);
          }
        });
        if (toRemove.length > 0) {
          await storageRemove(toRemove);
        }

        // STEP 4: Re-import all Chrome bookmarks as shortcuts (with clean names)
        await saveAllBookmarksAsShortcuts();

      } catch (e) {
        console.error('Tab0: Migration error:', e);
      }
    }, 1000);
  });
});

chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId === 'createShortcut') {
    let dashboardUrl = chrome.runtime.getURL('manage.html') + '?newurl=' + encodeURIComponent(tab.url) + '&newtitle=' + encodeURIComponent(tab.title);
    chrome.tabs.create({ url: dashboardUrl });
  }
});

// ============================================================
// OMNIBOX
// ============================================================

// Escape XML special characters for omnibox descriptions
function escapeXml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Build sorted suggestions from storage items, optionally filtered by text
function buildSuggestions(items, filterText) {
  let suggestions = [];
  let keys = Object.keys(items).filter(isShortcutKey);
  let search = (filterText || '').toLowerCase();

  for (let i = 0; i < keys.length; i++) {
    let key = keys[i];
    let data = items[key];
    let isFolder = typeof data === 'object' && data.type === 'folder';
    let url = isFolder ? '' : (typeof data === 'object' ? (data.url || '') : (data || ''));
    let count = typeof data === 'object' ? (data.count || 0) : 0;
    let tags = typeof data === 'object' && Array.isArray(data.tags) ? data.tags : [];
    let folderTitle = isFolder ? (data.folderTitle || '') : '';

    let searchableText = key + ' ' + url.toLowerCase() + ' ' + folderTitle.toLowerCase() + ' ' + tags.join(' ');
    if (search && !searchableText.includes(search)) continue;

    let lastAccessed = typeof data === 'object' ? (data.lastAccessed || 0) : 0;
    let tagLabel = tags.length > 0 ? ' [' + tags.join(', ') + ']' : '';

    let description;
    if (isFolder) {
      let urlCount = Array.isArray(data.urls) ? data.urls.length : 0;
      description = escapeXml(key) + ' <dim>' + escapeXml(tagLabel) + ' (' + urlCount + ' tabs)</dim> - <dim>' + escapeXml(folderTitle) + '</dim>';
    } else {
      description = escapeXml(key) + ' <dim>' + escapeXml(tagLabel) + '</dim> - <url>' + escapeXml(url) + '</url>';
    }

    suggestions.push({
      content: key,
      description: description,
      count: count,
      lastAccessed: lastAccessed
    });
  }

  // Sort: most used first, then most recently accessed, then alphabetical
  suggestions.sort((a, b) => {
    if (b.count !== a.count) return b.count - a.count;
    if (b.lastAccessed !== a.lastAccessed) return (b.lastAccessed || 0) - (a.lastAccessed || 0);
    return a.content.localeCompare(b.content);
  });
  return suggestions;
}

// Cache shortcuts in memory so we can serve them instantly on omnibox activation
let cachedShortcuts = null;

function refreshShortcutCache() {
  chrome.storage.sync.get(null, (items) => {
    if (chrome.runtime.lastError) return;
    cachedShortcuts = items;
  });
}

// Refresh cache on startup and whenever storage changes
refreshShortcutCache();
chrome.storage.onChanged.addListener(() => { refreshShortcutCache(); });

// When omnibox is first activated (user presses Tab after typing "0")
chrome.omnibox.onInputStarted.addListener(() => {
  let items = cachedShortcuts;
  if (!items) {
    chrome.omnibox.setDefaultSuggestion({
      description: 'Tab0: Type a shortcut name to go'
    });
    return;
  }
  let suggestions = buildSuggestions(items, '');
  if (suggestions.length > 0) {
    // Show the most-visited shortcut as the default action
    let top = suggestions[0];
    chrome.omnibox.setDefaultSuggestion({
      description: 'Tab0: <dim>Top shortcut:</dim> <match>' + escapeXml(top.content) + '</match> <dim>(' + suggestions.length + ' total) — type to filter</dim>'
    });
  } else {
    chrome.omnibox.setDefaultSuggestion({
      description: 'Tab0: No shortcuts yet — create one from the popup'
    });
  }
});

chrome.omnibox.onInputEntered.addListener(async (text, disposition) => {
  text = text.toLowerCase().trim();

  // If user presses Enter with empty text, open dashboard
  if (!text) {
    let dashUrl = chrome.runtime.getURL('manage.html');
    if (disposition === 'currentTab') {
      chrome.tabs.update({ url: dashUrl });
    } else {
      chrome.tabs.create({ url: dashUrl });
    }
    return;
  }

  try {
    let result = await storageGet(text);
    if (result[text] && isShortcutKey(text)) {
      let shortcutData = result[text];

      // Handle folder-type shortcuts: open all URLs
      if (typeof shortcutData === 'object' && shortcutData.type === 'folder' && Array.isArray(shortcutData.urls)) {
        shortcutData.count = (shortcutData.count || 0) + 1;
        shortcutData.lastAccessed = Date.now();
        await storageSet({ [text]: shortcutData });
        let urls = shortcutData.urls;
        if (urls.length > 0) {
          // Open first in current tab (or new tab based on disposition), rest always in new tabs
          if (disposition === 'currentTab') {
            chrome.tabs.update({ url: urls[0] });
          } else {
            chrome.tabs.create({ url: urls[0] });
          }
          for (let i = 1; i < urls.length; i++) {
            chrome.tabs.create({ url: urls[i] });
          }
        }
      } else if (typeof shortcutData === 'object' && shortcutData !== null && 'url' in shortcutData) {
        shortcutData.count = (shortcutData.count || 0) + 1;
        shortcutData.lastAccessed = Date.now();
        await storageSet({ [text]: shortcutData });
        logAccess(text, shortcutData.url);
        if (disposition === 'currentTab') {
          chrome.tabs.update({ url: shortcutData.url });
        } else {
          chrome.tabs.create({ url: shortcutData.url });
        }
      } else {
        let newData = { url: shortcutData, count: 1, lastAccessed: Date.now(), folder: '' };
        await storageSet({ [text]: newData });
        logAccess(text, newData.url);
        if (disposition === 'currentTab') {
          chrome.tabs.update({ url: newData.url });
        } else {
          chrome.tabs.create({ url: newData.url });
        }
      }
    } else {
      // No exact shortcut match — search by partial name, tag, or URL
      let allItems = await storageGet(null);
      let matches = buildSuggestions(allItems, text);

      if (matches.length > 0) {
        // Open the best match (first result, sorted by most used)
        let bestKey = matches[0].content;
        let bestData = allItems[bestKey];

        // Update access count
        if (typeof bestData === 'object') {
          bestData.count = (bestData.count || 0) + 1;
          bestData.lastAccessed = Date.now();
          await storageSet({ [bestKey]: bestData });
        }

        // Handle folder-type shortcuts
        if (typeof bestData === 'object' && bestData.type === 'folder' && Array.isArray(bestData.urls)) {
          let urls = bestData.urls;
          if (urls.length > 0) {
            if (disposition === 'currentTab') {
              chrome.tabs.update({ url: urls[0] });
            } else {
              chrome.tabs.create({ url: urls[0] });
            }
            for (let i = 1; i < urls.length; i++) {
              chrome.tabs.create({ url: urls[i] });
            }
          }
        } else {
          let bestUrl = typeof bestData === 'object' ? bestData.url : bestData;
          if (bestUrl) {
            logAccess(bestKey, bestUrl);
            if (disposition === 'currentTab') {
              chrome.tabs.update({ url: bestUrl });
            } else {
              chrome.tabs.create({ url: bestUrl });
            }
          }
        }
      } else {
        // Absolutely no results — open dashboard with prompt to create one
        let dashUrl = chrome.runtime.getURL('manage.html') + '?notfound=' + encodeURIComponent(text);
        if (disposition === 'currentTab') {
          chrome.tabs.update({ url: dashUrl });
        } else {
          chrome.tabs.create({ url: dashUrl });
        }
      }
    }
  } catch (err) {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon128.png',
      title: 'Tab0 - Error',
      message: 'Storage error: ' + err.message
    });
  }
});

chrome.omnibox.onInputChanged.addListener((text, suggest) => {
  // Use cached data first for instant response, then refresh from storage
  let respondWithItems = (items) => {
    let suggestions = buildSuggestions(items, text);

    // Update default suggestion text
    if (text.trim() === '') {
      if (suggestions.length > 0) {
        let top = suggestions[0];
        chrome.omnibox.setDefaultSuggestion({
          description: 'Tab0: <dim>Most visited:</dim> <match>' + escapeXml(top.content) + '</match> <dim>(' + suggestions.length + ' shortcuts) — type to filter</dim>'
        });
      } else {
        chrome.omnibox.setDefaultSuggestion({
          description: 'Tab0: No shortcuts yet'
        });
      }
    } else {
      let exactMatch = suggestions.find(s => s.content === text.toLowerCase().trim());
      if (exactMatch) {
        chrome.omnibox.setDefaultSuggestion({
          description: 'Tab0: Go to <match>' + escapeXml(exactMatch.content) + '</match>'
        });
      } else {
        chrome.omnibox.setDefaultSuggestion({
          description: 'Tab0: Search for <match>' + escapeXml(text) + '</match> <dim>(' + suggestions.length + ' matches)</dim>'
        });
      }
    }

    suggest(suggestions.map(s => ({ content: s.content, description: s.description })));
  };

  // Use cache for instant response, fall back to fresh fetch
  if (cachedShortcuts) {
    respondWithItems(cachedShortcuts);
  } else {
    chrome.storage.sync.get(null, (items) => {
      if (chrome.runtime.lastError) {
        suggest([]);
        return;
      }
      cachedShortcuts = items;
      respondWithItems(items);
    });
  }
});

// ============================================================
// BOOKMARK SYNC - Core functions
// ============================================================

// Helper: verify a bookmark ID exists and is a folder (not a bookmark with a URL)
async function isValidFolderId(id) {
  if (!id) return false;
  try {
    let nodes = await new Promise((resolve) => {
      chrome.bookmarks.get(id, (results) => {
        if (chrome.runtime.lastError) { resolve(null); return; }
        resolve(results);
      });
    });
    if (!nodes || nodes.length === 0) return false;
    return !nodes[0].url; // Folders have no URL property
  } catch (e) {
    return false;
  }
}

// Helper: find the "Other Bookmarks" folder ID dynamically instead of hardcoding '2'
async function getOtherBookmarksFolderId() {
  try {
    let tree = await new Promise(resolve => chrome.bookmarks.getTree(resolve));
    if (tree && tree[0] && tree[0].children) {
      // "Other Bookmarks" is typically the second child of the root
      for (let child of tree[0].children) {
        if (child.title === 'Other Bookmarks' || child.title === 'Other bookmarks') {
          return child.id;
        }
      }
      // Fallback: return second child if it exists and is a folder
      if (tree[0].children.length >= 2 && !tree[0].children[1].url) {
        return tree[0].children[1].id;
      }
    }
  } catch (e) {
    console.error('Tab0: Could not find Other Bookmarks folder:', e);
  }
  return '2'; // Last resort fallback
}

async function getOrCreateBookmarkFolder() {
  try {
    // Step 1: Look for existing "Tab0 Shortcuts" folder
    let results = await new Promise(r => {
      chrome.bookmarks.search({ title: 'Tab0 Shortcuts' }, r);
    });
    let folder = results.find(b => !b.url);
    if (folder) return folder;

    // Step 2: Check for legacy "Tab0" folder and rename it
    let legacy = await new Promise(r => {
      chrome.bookmarks.search({ title: 'Tab0' }, r);
    });

    // Find the "Other Bookmarks" folder ID dynamically
    let otherBmId = await getOtherBookmarksFolderId();

    let otherBmFolder = legacy.find(b => !b.url && b.parentId === otherBmId);
    if (otherBmFolder) {
      return await new Promise((resolve) => {
        chrome.bookmarks.update(otherBmFolder.id, { title: 'Tab0 Shortcuts' }, (updated) => {
          if (chrome.runtime.lastError) {
            console.warn('Tab0: Failed to rename legacy folder:', chrome.runtime.lastError.message);
          }
          resolve(updated || null);
        });
      });
    }

    // Step 3: Create new folder — verify otherBmId is actually a folder first
    let isValid = await isValidFolderId(otherBmId);
    if (!isValid) {
      console.error('Tab0: Other Bookmarks folder ID', otherBmId, 'is not valid, using root');
      otherBmId = '0'; // Root of bookmark tree as absolute fallback
    }

    return await new Promise((resolve) => {
      chrome.bookmarks.create({ title: 'Tab0 Shortcuts', parentId: otherBmId }, (newFolder) => {
        if (chrome.runtime.lastError) {
          console.error('Tab0: Failed to create Tab0 Shortcuts folder:', chrome.runtime.lastError.message);
          resolve(null);
        } else {
          resolve(newFolder);
        }
      });
    });
  } catch (e) {
    console.error('Tab0: getOrCreateBookmarkFolder error:', e);
    return null;
  }
}

// Get or create a subfolder inside the Tab0 folder
async function getOrCreateSubfolder(parentId, title) {
  let children = await new Promise(resolve => {
    chrome.bookmarks.getChildren(parentId, (result) => {
      if (chrome.runtime.lastError) { resolve([]); return; }
      resolve(result || []);
    });
  });
  let existing = children.find(c => !c.url && c.title === title);
  if (existing) return existing;
  return new Promise(resolve => {
    chrome.bookmarks.create({ parentId: parentId, title: title }, (result) => {
      if (chrome.runtime.lastError) { resolve(null); return; }
      resolve(result);
    });
  });
}

// Full sync: push all shortcuts to bookmarks
// Sync only standalone shortcuts (not linked to existing bookmarks) to the Tab0 folder.
// Bookmarks that already exist in the browser stay in their original location.
async function syncShortcutsToBookmarks() {
  try {
    let folder = await getOrCreateBookmarkFolder();
    if (!folder || !folder.id) {
      console.warn('Tab0: syncShortcutsToBookmarks skipped - no valid folder');
      return { success: false, error: 'No valid bookmark folder' };
    }
    let items = await storageGet(null);

    // Get existing children in the Tab0 folder
    let children = await new Promise(resolve => {
      chrome.bookmarks.getChildren(folder.id, (result) => {
        if (chrome.runtime.lastError) { resolve([]); return; }
        resolve(result || []);
      });
    });

    // Remove all existing children (clean slate for Tab0 folder only)
    for (let child of children) {
      try {
        if (child.url) {
          await new Promise(resolve => chrome.bookmarks.remove(child.id, resolve));
        } else {
          await new Promise(resolve => chrome.bookmarks.removeTree(child.id, resolve));
        }
      } catch (e) { /* ignore */ }
    }

    // Only sync shortcuts that are NOT linked to real bookmarks and NOT folder shortcuts
    let keys = Object.keys(items).filter(isShortcutKey);
    let standaloneKeys = keys.filter(key => {
      let data = items[key];
      if (typeof data === 'object' && data.type === 'folder') return false; // Skip folder shortcuts
      return !(typeof data === 'object' && data.bookmarkId);
    });

    // Put all standalone shortcuts directly in the Tab0 Shortcuts folder (flat, no subfolders)
    for (let key of standaloneKeys) {
      let data = items[key];
      let url = typeof data === 'object' ? (data.url || '') : (data || '');
      if (url) {
        await new Promise(resolve => {
          chrome.bookmarks.create({
            parentId: folder.id,
            title: key,
            url: url
          }, resolve);
        });
      }
    }

    return { success: true, count: standaloneKeys.length };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// Import from Tab0 bookmarks folder
async function importBookmarksAsShortcuts() {
  try {
    let folder = await getOrCreateBookmarkFolder();
    if (!folder || !folder.id) {
      console.warn('Tab0: importBookmarksAsShortcuts skipped - no valid folder');
      return { success: false, error: 'No valid bookmark folder' };
    }
    let children = await new Promise(resolve => {
      chrome.bookmarks.getSubTree(folder.id, (result) => {
        if (chrome.runtime.lastError) { resolve([]); return; }
        resolve(result || []);
      });
    });

    let imported = 0;
    let shortcuts = {};

    function processNode(node, category) {
      if (node.url) {
        let name = node.title.replace(/^\//, '').trim().toLowerCase().replace(/[^a-z0-9-]/g, '').substring(0, 15);
        if (name && node.url) {
          shortcuts[name] = {
            url: node.url, count: 0, folder: category || '',
            bookmarkId: node.id, bookmarkTitle: node.title,
            tags: [], createdAt: Date.now()
          };
          imported++;
        }
      }
      if (node.children) {
        let cat = (node.id !== folder.id) ? node.title : '';
        node.children.forEach(child => processNode(child, cat));
      }
    }

    if (children && children[0] && children[0].children) {
      children[0].children.forEach(child => processNode(child, ''));
    }

    if (imported > 0) {
      await storageSet(shortcuts);
    }

    return { success: true, count: imported };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ============================================================
// BIDIRECTIONAL SYNC - Storage → Bookmarks
// When shortcuts change in Tab0, update the Tab0 bookmark folder
// ============================================================
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'sync') return;

  // Check if any shortcut keys changed (not just internal keys)
  let shortcutChanged = Object.keys(changes).some(isShortcutKey);
  if (!shortcutChanged) return;

  // Debounce: wait a bit then do a full sync
  withSyncLock(async () => {
    await syncShortcutsToBookmarks();
  });
});

// ============================================================
// BIDIRECTIONAL SYNC - Bookmarks → Storage
// When bookmarks inside the Tab0 folder change, update shortcuts
// ============================================================

// Helper: check if a bookmark node is inside the Tab0 folder
async function isInsideTab0Folder(bookmarkId) {
  try {
    let tab0Folder = await getOrCreateBookmarkFolder();
    if (!tab0Folder || !tab0Folder.id) return false;
    let node = await new Promise(resolve => {
      chrome.bookmarks.get(bookmarkId, (results) => {
        if (chrome.runtime.lastError) { resolve(null); return; }
        resolve(results ? results[0] : null);
      });
    });
    if (!node) return false;

    // Walk up the parent chain
    let currentId = node.parentId;
    while (currentId) {
      if (currentId === tab0Folder.id) return true;
      try {
        let parent = await new Promise(resolve => {
          chrome.bookmarks.get(currentId, (results) => resolve(results ? results[0] : null));
        });
        if (!parent) return false;
        currentId = parent.parentId;
      } catch (e) {
        return false;
      }
    }
    return false;
  } catch (e) {
    return false;
  }
}

// When a bookmark is created inside Tab0 folder
chrome.bookmarks.onCreated.addListener((id, bookmark) => {
  if (!bookmark.url) return; // Ignore folder creation

  withSyncLock(async () => {
    if (!(await isInsideTab0Folder(id))) return;

    // Determine the folder name from the parent
    let tab0Folder = await getOrCreateBookmarkFolder();
    if (!tab0Folder || !tab0Folder.id) return;
    let parentNode = await new Promise(resolve => {
      chrome.bookmarks.get(bookmark.parentId, (results) => {
        if (chrome.runtime.lastError) { resolve(null); return; }
        resolve(results ? results[0] : null);
      });
    });
    let folderName = (parentNode && parentNode.id !== tab0Folder.id) ? parentNode.title : '';

    let name = bookmark.title.replace(/^\//, '').trim().toLowerCase().replace(/\s+/g, '-').substring(0, 15);
    if (!name) return;

    await storageSet({ [name]: { url: bookmark.url, count: 0, folder: folderName, bookmarkId: bookmark.id, bookmarkTitle: bookmark.title, tags: [], createdAt: Date.now() } });

    // Notify open dashboard tabs
    notifyDashboard('bookmarkChanged');
  });
});

// When a bookmark is removed from Tab0 folder
chrome.bookmarks.onRemoved.addListener((id, removeInfo) => {
  withSyncLock(async () => {
    // The bookmark is already removed so we can't check isInsideTab0Folder.
    // Check if any shortcut references this bookmark ID and remove it.
    try {
      let items = await storageGet(null);
      let keysToRemove = Object.keys(items).filter(isShortcutKey).filter(k => {
        let data = items[k];
        return typeof data === 'object' && data.bookmarkId === id;
      });
      if (keysToRemove.length > 0) {
        await storageRemove(keysToRemove);
        notifyDashboard('bookmarkChanged');
      }
    } catch (e) { /* ignore */ }
  });
});

// When a bookmark is changed (title/url) inside Tab0 folder
chrome.bookmarks.onChanged.addListener((id, changeInfo) => {
  withSyncLock(async () => {
    if (!(await isInsideTab0Folder(id))) return;
    // Reimport to pick up changes
    await importBookmarksAsShortcuts();
    notifyDashboard('bookmarkChanged');
  });
});

// When a bookmark is moved (between folders)
chrome.bookmarks.onMoved.addListener((id, moveInfo) => {
  withSyncLock(async () => {
    // Reimport to pick up the folder change
    await importBookmarksAsShortcuts();
    notifyDashboard('bookmarkChanged');
  });
});

// Notify dashboard tabs to refresh
function notifyDashboard(action) {
  chrome.runtime.sendMessage({ action: action }, () => {
    // Suppress error if no listeners (dashboard not open)
    void chrome.runtime.lastError;
  });
}

// ============================================================
// AUTO-SAVE ALL BOOKMARKS AS TAB0 SHORTCUTS
// Converts bookmark name to lowercase no-space form.
// If clashing, appends 1, 2, etc.
// ============================================================
// Auto-save all existing bookmarks as Tab0 shortcuts in storage only.
// Does NOT copy bookmarks into the Tab0 folder — they stay in place.
// Each shortcut stores bookmarkId so we know it's linked to a real bookmark.
async function saveAllBookmarksAsShortcuts() {
  try {
    let tree = await new Promise(resolve => chrome.bookmarks.getTree(resolve));
    let existing = await storageGet(null);
    let usedNames = {};
    Object.keys(existing).filter(isShortcutKey).forEach(k => { usedNames[k] = true; });

    // Also build a set of bookmark IDs that already have shortcuts
    let linkedBookmarkIds = {};
    Object.keys(existing).filter(isShortcutKey).forEach(k => {
      let data = existing[k];
      if (typeof data === 'object' && data.bookmarkId) {
        linkedBookmarkIds[data.bookmarkId] = true;
      }
    });

    let bookmarks = [];
    function walk(node) {
      if (node.url) bookmarks.push(node);
      if (node.children) node.children.forEach(walk);
    }
    tree.forEach(walk);

    let created = 0;
    let toSave = {};

    for (let bm of bookmarks) {
      if (!bm.url || !bm.title) continue;
      // Skip if this bookmark already has a shortcut linked
      if (linkedBookmarkIds[bm.id]) continue;

      // Generate shortcut name: lowercase, remove spaces and special chars
      let baseName = bm.title.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (!baseName) baseName = 'bookmark';
      baseName = baseName.substring(0, 15);

      let finalName = baseName;

      // Only add number suffix if the EXACT same name is taken by a DIFFERENT bookmark/shortcut
      if (usedNames[finalName] || toSave[finalName]) {
        // Check if the existing shortcut with this name is actually linked to THIS bookmark
        let existingData = existing[finalName];
        if (existingData && typeof existingData === 'object' && existingData.bookmarkId === bm.id) {
          // Already linked to this bookmark, skip
          continue;
        }
        // True clash with a different bookmark — add number suffix
        let counter = 2;
        while (usedNames[finalName] || toSave[finalName]) {
          let suffix = String(counter);
          finalName = baseName.substring(0, 15 - suffix.length) + suffix;
          counter++;
          if (counter > 999) break;
        }
      }

      if (finalName && finalName.length <= 15) {
        // Auto-generate tags from bookmark title and URL
        let autoTags = [];
        try {
          let hostname = new URL(bm.url).hostname.replace('www.', '');
          let domainTag = hostname.split('.')[0];
          if (domainTag && domainTag.length > 1) autoTags.push(domainTag);
        } catch (e) {}
        let titleWords = (bm.title || '').toLowerCase()
          .replace(/[^a-z0-9\s]/g, ' ')
          .split(/\s+/)
          .filter(w => w.length > 2 && !['the', 'and', 'for', 'com', 'www', 'http', 'https', 'org', 'net'].includes(w));
        titleWords.forEach(w => {
          if (autoTags.length < 3 && !autoTags.includes(w)) autoTags.push(w);
        });
        let urlStr = (bm.url || '').toLowerCase();
        if (autoTags.length < 3) {
          if (urlStr.includes('github') || urlStr.includes('gitlab')) { if (!autoTags.includes('dev')) autoTags.push('dev'); }
          else if (urlStr.includes('docs.') || urlStr.includes('/docs') || urlStr.includes('wiki')) { if (!autoTags.includes('docs')) autoTags.push('docs'); }
          else if (urlStr.includes('mail.') || urlStr.includes('gmail') || urlStr.includes('outlook')) { if (!autoTags.includes('email')) autoTags.push('email'); }
          else if (urlStr.includes('drive.') || urlStr.includes('dropbox') || urlStr.includes('cloud')) { if (!autoTags.includes('cloud')) autoTags.push('cloud'); }
          else if (urlStr.includes('youtube') || urlStr.includes('vimeo') || urlStr.includes('video')) { if (!autoTags.includes('video')) autoTags.push('video'); }
          else if (urlStr.includes('slack') || urlStr.includes('discord') || urlStr.includes('teams')) { if (!autoTags.includes('chat')) autoTags.push('chat'); }
          else if (urlStr.includes('figma') || urlStr.includes('canva') || urlStr.includes('design')) { if (!autoTags.includes('design')) autoTags.push('design'); }
          else if (urlStr.includes('support') || urlStr.includes('desk') || urlStr.includes('helpdesk')) { if (!autoTags.includes('support')) autoTags.push('support'); }
        }
        autoTags = autoTags.slice(0, 3);

        toSave[finalName] = {
          url: bm.url,
          count: 0,
          bookmarkId: bm.id,
          bookmarkTitle: bm.title,
          tags: autoTags
        };
        usedNames[finalName] = true;
        created++;
      }
    }

    if (Object.keys(toSave).length > 0) {
      // Protect against exceeding chrome.storage.sync limits
      // Max: 512 items total, 102,400 bytes total, 8,192 bytes per item
      let currentItems = await storageGet(null);
      let currentCount = Object.keys(currentItems).length;
      let toSaveKeys = Object.keys(toSave);
      let availableSlots = Math.max(0, 500 - currentCount); // Leave 12 slots as buffer

      if (toSaveKeys.length > availableSlots) {
        console.warn('Tab0: Limiting bookmark import from ' + toSaveKeys.length + ' to ' + availableSlots + ' to avoid quota limits');
        let limited = {};
        toSaveKeys.slice(0, availableSlots).forEach(k => { limited[k] = toSave[k]; });
        toSave = limited;
        created = availableSlots;
      }

      // Save in batches to avoid per-call size limits
      let batchSize = 50;
      let allKeys = Object.keys(toSave);
      for (let i = 0; i < allKeys.length; i += batchSize) {
        let batch = {};
        allKeys.slice(i, i + batchSize).forEach(k => { batch[k] = toSave[k]; });
        try {
          await storageSet(batch);
        } catch (e) {
          console.error('Tab0: Batch save failed at index ' + i + ':', e.message);
          break; // Stop saving if we hit quota
        }
      }
    }

    return { success: true, count: created };
  } catch (err) {
    console.error('Tab0: saveAllBookmarksAsShortcuts error:', err.message);
    return { success: false, error: err.message };
  }
}

// ============================================================
// MESSAGE LISTENER
// ============================================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'syncToBookmarks') {
    withSyncLock(() => syncShortcutsToBookmarks()).then(sendResponse);
    return true;
  }
  if (request.action === 'importFromBookmarks') {
    withSyncLock(() => importBookmarksAsShortcuts()).then(sendResponse);
    return true;
  }
  if (request.action === 'getTab0FolderId') {
    getOrCreateBookmarkFolder().then(folder => sendResponse(folder ? folder.id : undefined));
    return true;
  }
  if (request.action === 'getBookmarkTree') {
    chrome.bookmarks.getTree((tree) => sendResponse(tree));
    return true;
  }
  if (request.action === 'moveBookmark') {
    chrome.bookmarks.move(request.id, { parentId: request.parentId, index: request.index }, (result) => {
      if (chrome.runtime.lastError) { sendResponse({ error: chrome.runtime.lastError.message }); return; }
      sendResponse(result);
    });
    return true;
  }
  if (request.action === 'updateBookmark') {
    let changes = {};
    if (request.title !== undefined) changes.title = request.title;
    if (request.url !== undefined) changes.url = request.url;
    chrome.bookmarks.update(request.id, changes, (result) => {
      if (chrome.runtime.lastError) { sendResponse({ error: chrome.runtime.lastError.message }); return; }
      // If a parentId move is also requested, do that too
      if (request.parentId) {
        chrome.bookmarks.move(request.id, { parentId: request.parentId }, (moveResult) => {
          if (chrome.runtime.lastError) { sendResponse({ error: chrome.runtime.lastError.message }); return; }
          sendResponse(moveResult);
        });
      } else {
        sendResponse(result);
      }
    });
    return true;
  }
  if (request.action === 'removeBookmark') {
    chrome.bookmarks.remove(request.id, () => {
      if (chrome.runtime.lastError) { sendResponse({ error: chrome.runtime.lastError.message }); return; }
      sendResponse({ success: true });
    });
    return true;
  }
  if (request.action === 'saveAllBookmarksAsShortcuts') {
    saveAllBookmarksAsShortcuts().then(sendResponse);
    return true;
  }
  // Get the shortcut key linked to a specific bookmark ID
  if (request.action === 'getShortcutForBookmark') {
    chrome.storage.sync.get(null, (items) => {
      let found = null;
      Object.keys(items).filter(isShortcutKey).forEach(key => {
        let data = items[key];
        if (typeof data === 'object' && data.bookmarkId === request.bookmarkId) {
          found = { key: key, data: data };
        }
      });
      sendResponse(found);
    });
    return true;
  }
  // Update shortcut key (rename) for a bookmark-linked shortcut
  if (request.action === 'updateShortcutKey') {
    let oldKey = request.oldKey;
    let newKey = request.newKey;
    let extraData = request.extraData || {};
    chrome.storage.sync.get(oldKey, (result) => {
      let data = result[oldKey] || {};
      // Merge any extra data
      Object.assign(data, extraData);
      if (oldKey === newKey) {
        // Just update data
        chrome.storage.sync.set({ [newKey]: data }, () => sendResponse({ success: true }));
      } else {
        chrome.storage.sync.remove(oldKey, () => {
          chrome.storage.sync.set({ [newKey]: data }, () => sendResponse({ success: true }));
        });
      }
    });
    return true;
  }
  if (request.action === 'getDailyStats') {
    chrome.storage.local.get('__tab0_daily_stats', (result) => {
      sendResponse(result['__tab0_daily_stats'] || {});
    });
    return true;
  }
  if (request.action === 'getBookmarkFolders') {
    chrome.bookmarks.getTree((tree) => {
      let folders = [];
      function walkFolders(node, depth) {
        if (!node.url && node.title !== undefined) {
          folders.push({ id: node.id, title: node.title, depth: depth });
        }
        if (node.children) {
          node.children.forEach(child => walkFolders(child, depth + 1));
        }
      }
      if (tree[0] && tree[0].children) {
        tree[0].children.forEach(root => walkFolders(root, 0));
      }
      sendResponse(folders);
    });
    return true;
  }
});
